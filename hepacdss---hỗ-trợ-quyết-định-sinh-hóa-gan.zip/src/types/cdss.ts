export type Gender = 'male' | 'female';

export interface PatientLabs {
  age?: number;
  gender: Gender;
  bmi?: number;
  // Transaminases
  alt: number; // Alanine aminotransferase (U/L)
  altUln: number; // Upper limit of normal for ALT (U/L)
  ast: number; // Aspartate aminotransferase (U/L)
  astUln: number; // Upper limit of normal for AST (U/L)
  // Cholestasis markers
  alp: number; // Alkaline phosphatase (U/L)
  alpUln: number; // Upper limit of normal for ALP (U/L)
  ggt?: number; // Gamma-glutamyl transferase (U/L)
  ggtUln?: number;
  // Bilirubin
  totalBilirubin: number; // mg/dL
  directBilirubin: number; // mg/dL (conjugated)
  // Synthetic function
  albumin?: number; // g/dL
  inr?: number; // Prothrombin Time INR
  // Hematology & Fibrosis
  platelets?: number; // 10^9 / L
  // Additional specialized markers
  ferritin?: number; // ng/mL
  transferrinSat?: number; // %
  creatinine?: number; // mg/dL
  sodium?: number; // mEq/L
  ck?: number; // Creatine kinase U/L
  vitaminD?: number; // 25-OH Vitamin D (ng/mL)
  // Clinical Flags
  alcoholIntake?: number; // grams/week (>140 for females, >210 for males)
  weeklyAlcoholUnits?: number; // UK units/week (1 unit ~ 8g alcohol)
  auditCScore?: number; // AUDIT-C screening score (0-12)
  hasDiabetesOrIFG?: boolean; // Type 2 Diabetes or Impaired Fasting Glucose (for NAFLD Fibrosis Score)
  isTakingStatin?: boolean; // Statin therapy flag
  hasEncephalopathy?: boolean;
  hasAscites?: boolean;
  pregnant?: boolean;
  // Specialized / Contextual Flags
  strenuousExercise?: boolean;
  medications?: string;
  patientName?: string;
  patientId?: string;
  ultrasoundBiliaryDilatation?: 'dilated' | 'non-dilated' | 'not-done';
  notes?: string;
}

export type InjuryPattern = 'Hepatocellular' | 'Cholestatic' | 'Mixed' | 'Isolated Hyperbilirubinemia' | 'Normal / Borderline';

export type ElevationSeverity = 'Normal' | 'Borderline (<2x ULN)' | 'Mild (2-5x ULN)' | 'Moderate (5-15x ULN)' | 'Severe (>15x ULN)' | 'Massive (>10,000 U/L)';

export type CDSSRiskTier = 'Tối khẩn cấp / Cấp cứu' | 'Nguy cơ cao' | 'Theo dõi tích cực' | 'Nguy cơ thấp / Lành tính';

export interface DeRitisPathology {
  category: string;
  clinicalMeaning: string;
  cellularMechanism: string;
  kineticsNote: string;
}

export interface SLDClassification {
  category: 'MASLD' | 'MetALD' | 'ALD' | 'Non-SLD' | 'Nghi ngờ';
  title: string;
  subtext: string;
  alcoholIntakeGramsPerWeek: number;
  alcoholThresholdNote: string;
  metabolicCriteriaMet: boolean;
  recommendations: string[];
}

export interface StatinSafetyGuidance {
  isSafe: boolean;
  badge: 'An toàn tiếp tục' | 'Cân nhắc giảm liều / Theo dõi' | 'Tạm ngưng & Đánh giá lại';
  title: string;
  recommendation: string;
  evidenceNote: string;
}

export interface ILFTRuleItem {
  name: string;
  code: string;
  targetAetiology: string;
  indication: string;
  priority: 'Bắt buộc (Tier 1)' | 'Mở rộng (Tier 2)' | 'Chuyên sâu';
}

export interface CDSSAnalysis {
  pattern: InjuryPattern;
  rRatio: number;
  deRitisRatio: number;
  altMultiples: number;
  astMultiples: number;
  alpMultiples: number;
  severity: ElevationSeverity;
  riskTier: CDSSRiskTier;
  conjugatedPercent: number;
  isConjugatedPredominant: boolean;
  isUnconjugatedPredominant: boolean;
  syntheticImpairment: boolean;
  isAcuteLiverFailureWarning: boolean;
  isMassiveTransaminitisWarning: boolean;
  hysLawWarning: boolean;
  rhabdoWarning: boolean;
  extrahepaticAstWarning: boolean;
  wilsonIndex?: {
    isTriggered: boolean;
    astAltRatio: number;
    alpBilRatio?: number;
    note: string;
  };
  maddreyScore?: number;
  maddreySevere?: boolean;
  isolatedAlpOrigin?: 'hepatic_confirmed' | 'suspect_bone_or_other' | 'indeterminate';
  isolatedAlpVitaminDAdvice?: {
    isTriggered: boolean;
    recommendation: string;
  };
  deRitisPathology: DeRitisPathology;
  fib4Score?: number;
  fib4Stage?: string;
  fib4AgeAdjustedNote?: string;
  nfsScore?: number;
  nfsStage?: string;
  nfsAgeAdjustedNote?: string;
  sldClassification?: SLDClassification;
  statinGuidance?: StatinSafetyGuidance;
  ilftReflexScreen?: {
    tier1StandardScreen: ILFTRuleItem[];
    tier2ExtendedScreen: ILFTRuleItem[];
    summary: string;
  };
  apriScore?: number;
  apriStage?: string;
  meldScore?: number;
  primaryImpression: string;
  keyFindings: string[];
  differentialDiagnoses: {
    disease: string;
    likelihood: 'Rất cao' | 'Cao' | 'Trung bình' | 'Cần loại trừ';
    clues: string;
    recommendedNextStep: string;
  }[];
  stepByStepRecommendations: string[];
  guidelineReferences: string[];
}

export interface RucamAssessmentData {
  pattern: 'Hepatocellular' | 'Cholestatic' | 'Mixed';
  timeToOnset: number; // days from start of drug
  timeFromCessation?: number; // days from drug cessation to onset
  dechallengeDecreasePct?: number; // % drop within 8-30 days
  alcoholIntakeSignificant: boolean;
  ageOver55: boolean;
  pregnancy: boolean;
  concomitantDrugsCount: number;
  alternativeCausesRuledOut: 'full' | 'partial' | 'alternative_found';
  previousHepatotoxicityInLabel: boolean;
  previousHepatotoxicityPublished: boolean;
  unintentionalRechallengeResult: 'positive' | 'negative' | 'not_tested';
}

export interface RucamScoreResult {
  totalScore: number;
  causalityCategory: 'Rất chắc chắn (>8)' | 'Khả năng cao (6-8)' | 'Có thể (3-5)' | 'Ít khả năng (1-2)' | 'Loại trừ (≤0)';
  breakdown: { domain: string; score: number; note: string }[];
  clinicalAdvice: string;
  hlaGeneticAssociations: { drug: string; allele: string; oddsRatio: string }[];
}

export interface ClinicalCase {
  id: string;
  title: string;
  patientProfile: string;
  category: 'Viral' | 'Alcohol' | 'Metabolic' | 'Biliary' | 'Toxic/DILI' | 'Autoimmune' | 'Genetic' | 'Emergency';
  history: string;
  labs: PatientLabs;
  teachingPoints: string[];
  expertCommentary: string;
}

export interface BiomarkerInfo {
  id: string;
  code: string;
  nameVi: string;
  nameEn: string;
  category: 'Hepatocellular' | 'Cholestatic' | 'Bilirubin' | 'Synthetic' | 'Specialized' | 'Non-hepatic';
  normalRangeMale: string;
  normalRangeFemale: string;
  halfLife: string;
  cellularOrigin: string;
  physiologicalRole: string;
  causesOfElevation: string[];
  causesOfReduction?: string[];
  clinicalPearls: string[];
  testingPitfalls: string[];
}

export interface AlgorithmStep {
  id: string;
  title: string;
  description: string;
  condition?: string;
  actions: string[];
  substeps?: AlgorithmStep[];
}
