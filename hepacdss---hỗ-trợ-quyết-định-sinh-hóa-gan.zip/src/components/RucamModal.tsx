import React, { useState } from 'react';
import { RucamAssessmentData } from '../types/cdss';
import { calculateRucamScore } from '../utils/rucamCalculator';
import { X, ShieldAlert, Award, Dna, Info, CheckCircle2, RotateCcw } from 'lucide-react';

interface RucamModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPattern?: 'Hepatocellular' | 'Cholestatic' | 'Mixed';
  patientAge?: number;
}

export const RucamModal: React.FC<RucamModalProps> = ({
  isOpen,
  onClose,
  defaultPattern = 'Hepatocellular',
  patientAge = 45
}) => {
  const [data, setData] = useState<RucamAssessmentData>({
    pattern: defaultPattern === 'Cholestatic' || defaultPattern === 'Mixed' ? defaultPattern : 'Hepatocellular',
    timeToOnset: 21,
    timeFromCessation: 5,
    dechallengeDecreasePct: 60,
    alcoholIntakeSignificant: false,
    ageOver55: patientAge >= 55,
    pregnancy: false,
    concomitantDrugsCount: 0,
    alternativeCausesRuledOut: 'full',
    previousHepatotoxicityInLabel: true,
    previousHepatotoxicityPublished: true,
    unintentionalRechallengeResult: 'not_tested'
  });

  if (!isOpen) return null;

  const result = calculateRucamScore(data);

  const resetForm = () => {
    setData({
      pattern: defaultPattern === 'Cholestatic' || defaultPattern === 'Mixed' ? defaultPattern : 'Hepatocellular',
      timeToOnset: 21,
      timeFromCessation: 5,
      dechallengeDecreasePct: 60,
      alcoholIntakeSignificant: false,
      ageOver55: patientAge >= 55,
      pregnancy: false,
      concomitantDrugsCount: 0,
      alternativeCausesRuledOut: 'full',
      previousHepatotoxicityInLabel: true,
      previousHepatotoxicityPublished: true,
      unintentionalRechallengeResult: 'not_tested'
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-rose-500/20 text-rose-400 rounded-xl">
              <ShieldAlert className="w-5 h-5 sm:w-6 sm:h-6" />
            </span>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  Thang Điểm RUCAM & Độc Tính Gan Do Thuốc (DILI)
                </h3>
                <span className="text-[10px] bg-rose-900/60 text-rose-300 font-extrabold px-2 py-0.5 rounded border border-rose-700">
                  ACG 2017 & DILI Update 2023
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Roussel Uclaf Causality Assessment Method — Tiêu chuẩn vàng xác định mối quan hệ nhân quả thuốc - tổn thương gan
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={resetForm}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              title="Đặt lại mặc định"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: Two Columns */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Real-Time Result Banner */}
          <div className="p-4 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 text-white rounded-2xl border border-slate-800 shadow-md">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold text-teal-400 tracking-wider">
                  Kết Quả Đánh Giá Quan Hệ Nhân Quả (Causality Grading)
                </span>
                <div className="flex items-center space-x-3">
                  <span className="text-3xl font-black font-mono text-white">
                    {result.totalScore} <span className="text-sm font-semibold text-slate-400">điểm</span>
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border ${
                    result.totalScore > 8 ? 'bg-rose-500/30 text-rose-300 border-rose-500' :
                    result.totalScore >= 6 ? 'bg-amber-500/30 text-amber-300 border-amber-500' :
                    result.totalScore >= 3 ? 'bg-blue-500/30 text-blue-300 border-blue-500' :
                    'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    {result.causalityCategory}
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-200 max-w-md leading-relaxed border-t sm:border-t-0 sm:border-l border-slate-700 sm:pl-4 pt-2 sm:pt-0">
                {result.clinicalAdvice}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Form Inputs */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* Domain 1: Injury Pattern */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="text-xs font-bold text-slate-800 block">
                  1. Kiểu tổn thương sinh hóa theo R-Ratio:
                </label>
                <div className="grid grid-cols-3 gap-1.5 bg-white p-1 rounded-xl border border-slate-200 text-xs">
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, pattern: 'Hepatocellular' }))}
                    className={`py-1.5 rounded-lg font-bold transition-all ${
                      data.pattern === 'Hepatocellular'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Tế bào gan (R &gt; 5)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, pattern: 'Cholestatic' }))}
                    className={`py-1.5 rounded-lg font-bold transition-all ${
                      data.pattern === 'Cholestatic'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Ứ mật (R &lt; 2)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, pattern: 'Mixed' }))}
                    className={`py-1.5 rounded-lg font-bold transition-all ${
                      data.pattern === 'Mixed'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Hỗn hợp (2-5)
                  </button>
                </div>
              </div>

              {/* Domain 2: Latency / Time to onset */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-800">
                    2. Khoảng thời gian từ lúc bắt đầu dùng thuốc đến khi khởi phát:
                  </label>
                  <span className="text-xs font-black text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                    {data.timeToOnset} ngày
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="180"
                  value={data.timeToOnset}
                  onChange={(e) => setData(p => ({ ...p, timeToOnset: Number(e.target.value) }))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                  <span>&lt; 5 ngày (Mẫn cảm trước)</span>
                  <span className="font-bold text-teal-700">5 - 90 ngày (Kinh điển nhất, +2đ)</span>
                  <span>&gt; 90 ngày (+1đ)</span>
                </div>
              </div>

              {/* Domain 3: Dechallenge Course */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-800">
                    3. Mức độ giảm men gan sau khi ngưng thuốc (Dechallenge):
                  </label>
                  <span className="text-xs font-mono font-bold text-emerald-700">
                    {data.dechallengeDecreasePct}%
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, dechallengeDecreasePct: 60 }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      (data.dechallengeDecreasePct ?? 0) >= 50
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Giảm ≥ 50% trong 8-30 ngày (+3đ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, dechallengeDecreasePct: 30 }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      (data.dechallengeDecreasePct ?? 0) >= 20 && (data.dechallengeDecreasePct ?? 0) < 50
                        ? 'bg-teal-600 text-white border-teal-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Giảm 20-50% (+1đ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, dechallengeDecreasePct: -10 }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      (data.dechallengeDecreasePct ?? 0) < 0
                        ? 'bg-rose-600 text-white border-rose-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Không giảm / Tăng tiếp (-2đ)
                  </button>
                </div>
              </div>

              {/* Domain 4: Risk Factors & Concomitant Drugs */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5">
                <label className="text-xs font-bold text-slate-800 block">
                  4. Yếu tố nguy cơ cơ địa & Thuốc phối hợp:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, ageOver55: !p.ageOver55 }))}
                    className={`p-2 rounded-xl border flex items-center justify-between font-bold ${
                      data.ageOver55 ? 'bg-teal-50 border-teal-300 text-teal-900' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <span>Tuổi ≥ 55 (+1)</span>
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center text-[9px] ${
                      data.ageOver55 ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-300'
                    }`}>
                      {data.ageOver55 && '✓'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, alcoholIntakeSignificant: !p.alcoholIntakeSignificant }))}
                    className={`p-2 rounded-xl border flex items-center justify-between font-bold ${
                      data.alcoholIntakeSignificant ? 'bg-teal-50 border-teal-300 text-teal-900' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <span>Tiêu thụ rượu (+1)</span>
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center text-[9px] ${
                      data.alcoholIntakeSignificant ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-300'
                    }`}>
                      {data.alcoholIntakeSignificant && '✓'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, pregnancy: !p.pregnancy }))}
                    className={`p-2 rounded-xl border flex items-center justify-between font-bold ${
                      data.pregnancy ? 'bg-teal-50 border-teal-300 text-teal-900' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <span>Mang thai (+1 ứ mật)</span>
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center text-[9px] ${
                      data.pregnancy ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-300'
                    }`}>
                      {data.pregnancy && '✓'}
                    </span>
                  </button>
                </div>

                <div className="pt-2 border-t border-slate-200">
                  <div className="flex justify-between items-center mb-1 text-xs">
                    <span className="font-bold text-slate-700">Số thuốc dùng đồng thời có nguy cơ gan:</span>
                    <select
                      value={data.concomitantDrugsCount}
                      onChange={(e) => setData(p => ({ ...p, concomitantDrugsCount: Number(e.target.value) }))}
                      className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-bold"
                    >
                      <option value={0}>0 (Không có thuốc khác, 0đ)</option>
                      <option value={1}>1 thuốc đồng thời (ít nghi ngờ hơn, 0đ)</option>
                      <option value={2}>≥ 2 thuốc đồng thời có nguy cơ (-2đ)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Domain 5: Alternative Causes */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <label className="text-xs font-bold text-slate-800 block">
                  5. Bilan loại trừ các nguyên nhân không do thuốc (HAV, HBV, HCV, Tự miễn, Siêu âm):
                </label>
                <div className="grid grid-cols-3 gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, alternativeCausesRuledOut: 'full' }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      data.alternativeCausesRuledOut === 'full'
                        ? 'bg-teal-600 text-white border-teal-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Đã loại trừ toàn bộ (+2đ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, alternativeCausesRuledOut: 'partial' }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      data.alternativeCausesRuledOut === 'partial'
                        ? 'bg-amber-600 text-white border-amber-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Loại trừ một phần (+1đ)
                  </button>
                  <button
                    type="button"
                    onClick={() => setData(p => ({ ...p, alternativeCausesRuledOut: 'alternative_found' }))}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      data.alternativeCausesRuledOut === 'alternative_found'
                        ? 'bg-rose-600 text-white border-rose-500 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Tìm thấy bệnh khác (-3đ)
                  </button>
                </div>
              </div>
            </div>

            {/* Right Column: Breakdown Table & Genetic Associations */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* Detailed Breakdown */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5">
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wide flex items-center space-x-1.5">
                  <Award className="w-4 h-4 text-teal-600" />
                  <span>Chi tiết điểm từng miền RUCAM</span>
                </h4>
                <div className="divide-y divide-slate-200 text-xs">
                  {result.breakdown.map((item, idx) => (
                    <div key={idx} className="py-2 flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <span className="font-bold text-slate-800 block text-[11px]">{item.domain}</span>
                        <p className="text-[10px] text-slate-500 leading-tight">{item.note}</p>
                      </div>
                      <span className={`font-mono font-bold text-xs shrink-0 px-2 py-0.5 rounded ${
                        item.score > 0 ? 'bg-emerald-100 text-emerald-800' :
                        item.score < 0 ? 'bg-rose-100 text-rose-800' :
                        'bg-slate-200 text-slate-700'
                      }`}>
                        {item.score > 0 ? `+${item.score}` : item.score}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* HLA Genetic Susceptibility Panel (Allison et al. 2023 Update) */}
              <div className="bg-gradient-to-br from-indigo-50/80 to-purple-50/80 p-4 rounded-2xl border border-indigo-100 space-y-2.5">
                <div className="flex items-center space-x-2">
                  <span className="p-1 rounded bg-indigo-600 text-white">
                    <Dna className="w-3.5 h-3.5" />
                  </span>
                  <h4 className="text-xs font-extrabold text-indigo-950 uppercase tracking-wide">
                    Đột Biến Gen HLA & Tính Nhạy Cảm DILI (Update 2023)
                  </h4>
                </div>
                <p className="text-[11px] text-indigo-900 leading-relaxed">
                  Các nghiên cứu GWAS gần đây chứng minh liên quan chặt chẽ giữa các alen kháng nguyên bạch cầu người (HLA) với DILI đặc ứng (Idiosyncratic DILI):
                </p>
                <div className="space-y-1.5 pt-1">
                  {result.hlaGeneticAssociations.slice(0, 4).map((hla, idx) => (
                    <div key={idx} className="p-2 bg-white rounded-xl border border-indigo-100/80 text-[11px] flex justify-between items-center">
                      <div>
                        <strong className="text-indigo-950">{hla.drug}</strong>
                        <span className="text-indigo-700 ml-1.5 font-mono text-[10px]">({hla.allele})</span>
                      </div>
                      <span className="text-[10px] font-bold text-indigo-900 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                        OR: {hla.oddsRatio}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Nguồn tham khảo: Journal of Toxicology and Environmental Health (Allison et al. 2023 Update) & ACG 2017
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
          >
            Đóng & Áp Dụng Kết Quả
          </button>
        </div>

      </div>
    </div>
  );
};
