export interface FlowchartBranch {
  id: string;
  title: string;
  conditionDescription: string;
  color: string;
  clinicalActions: string[];
  furtherInvestigations: string[];
  keyDiagnosticPearls: string[];
}

export interface ClinicalAlgorithm {
  id: string;
  title: string;
  subtitle: string;
  sourceGuideline: string;
  overview: string;
  branches: FlowchartBranch[];
}

export const CLINICAL_ALGORITHMS: ClinicalAlgorithm[] = [
  {
    id: 'algo-transaminases',
    title: 'Lưu Đồ Tiếp Cận Tăng Aminotransferase (ALT / AST)',
    subtitle: 'Phân tầng nguy cơ và thứ tự xét nghiệm theo nồng độ bội số giới hạn trên bình thường (ULN)',
    sourceGuideline: 'ACG Clinical Guideline 2017 & Gastroenterology 2026',
    overview: 'Dựa trên nồng độ ALT ULN chuẩn là 33 U/L (nam) và 25 U/L (nữ). Việc tiếp cận được phân thành 5 mức độ để cân bằng giữa chi phí, tránh xét nghiệm tràn lan không cần thiết và không bỏ sót các cấp cứu tối khẩn.',
    branches: [
      {
        id: 'borderline-mild',
        title: 'Tăng nhẹ & Ranh giới (< 2x đến 2 - 5x ULN)',
        conditionDescription: 'ALT hoặc AST tăng dưới 5 lần ULN (thường ALT < 120-165 U/L). Bệnh nhân không có dấu hiệu suy gan cấp.',
        color: 'emerald',
        clinicalActions: [
          'Khai thác kỹ tiền sử: lượng rượu bia uống hàng tuần, thuốc kê đơn, thuốc OTC, thực phẩm chức năng, thảo dược, tiền sử truyền máu hoặc xăm mình.',
          'Ngưng ngay thuốc có độc tính gan tiềm ẩn và rượu bia.',
          'Đánh giá các yếu tố nguy cơ của Gan thoái hóa mỡ chuyển hóa (MASLD): BMI, vòng bụng, đái tháo đường, rối loạn lipid máu, tăng huyết áp.',
          'Lặp lại xét nghiệm sau 2-4 tuần để xác nhận tính chất tăng dai dẳng trước khi làm bilan chuyên sâu tốn kém.'
        ],
        furtherInvestigations: [
          'Xét nghiệm ban đầu (Bậc 1): HBsAg, anti-HBs, anti-HBc, anti-HCV (khẳng định bằng HCV RNA nếu dương tính).',
          'Siêu âm ổ bụng tổng quát: kiểm tra cấu trúc nhu mô gan (gan nhiễm mỡ, xơ gan thô), kích thước lách, đường kính tĩnh mạch cửa (bình thường < 12mm).',
          'Bilan sắt: Sắt huyết thanh, Ferritin, Độ bão hòa Transferrin (nếu TSAT ≥ 45% -> xem xét phân tích đột biến gen HFE).',
          'Nếu men gan vẫn tăng dai dẳng > 3 - 6 tháng không rõ nguyên nhân (Bậc 2): ANA, ASMA, Định lượng IgG, Ceruloplasmin (nếu < 55 tuổi), Phenotype Alpha-1 Antitrypsin, Kháng thể Celiac (anti-tTG IgA), TSH.'
        ],
        keyDiagnosticPearls: [
          'Tỷ số AST/ALT > 2:1 rất gợi ý bệnh gan do rượu (ALD).',
          'Tính ngay chỉ số FIB-4: nếu < 1.30 có thể loại trừ an tâm xơ hóa tiến triển (NPV > 90%).'
        ]
      },
      {
        id: 'moderate',
        title: 'Tăng mức độ vừa (5 - 15x ULN)',
        conditionDescription: 'ALT hoặc AST trong khoảng 165 - 500 U/L. Thường gặp trong viêm gan cấp hoặc đợt bùng phát cấp của viêm gan mạn.',
        color: 'amber',
        clinicalActions: [
          'Khám phát hiện ngay các dấu hiệu cảnh báo suy gan cấp: tri giác thay đổi, mất định hướng, dấu run vỗ cánh (Asterixis), xuất huyết dưới da.',
          'Đánh giá chức năng tổng hợp khẩn: PT/INR và Albumin.',
          'Nếu có vàng da hoặc đau hạ sườn phải: siêu âm cấp cứu tìm sỏi mật di chuyển hoặc tắc mạch gan.'
        ],
        furtherInvestigations: [
          'Hội chứng viêm gan virus cấp: IgM anti-HAV, HBsAg + IgM anti-HBc, anti-HCV kèm HCV RNA PCR.',
          'Tự miễn: ANA, ASMA, Anti-LKM1, Định lượng IgG toàn phần.',
          'Chuyển hóa & Độc chất: Bilan sắt, Ceruloplasmin, nồng độ Acetaminophen huyết thanh.',
          'Siêu âm Doppler mạch máu gan: Đánh giá tưới máu động mạch gan và hệ thống tĩnh mạch gan (loại trừ hội chứng Budd-Chiari).'
        ],
        keyDiagnosticPearls: [
          'Ở mức 5-15x ULN, các nguyên nhân virus cấp, viêm gan tự miễn cấp và độc chất chiếm ưu thế áp đảo so với MASLD thuần túy.'
        ]
      },
      {
        id: 'severe-massive',
        title: 'Tăng nặng (>15x ULN) & Khổng lồ (>10,000 U/L)',
        conditionDescription: 'ALT hoặc AST > 500 U/L (thường vài nghìn đến > 10,000 U/L). Tình trạng hoại tử tế bào gan ồ ạt cấp tính!',
        color: 'rose',
        clinicalActions: [
          'ĐÁNH GIÁ NGUY CƠ SUY GAN CẤP (ALF): Nếu INR ≥ 1.5 + Bệnh não gan -> Kích hoạt ngay quy trình hội chẩn khẩn cấp trung tâm ghép gan!',
          'Khảo sát ngay 3 nguyên nhân hàng đầu của mức >10,000 U/L: (1) Ngộ độc Acetaminophen; (2) Sốc gan do thiếu máu cục bộ (Ischemic hepatopathy); (3) Nấm độc Amanita phalloides.',
          'Chỉ định ngay N-Acetylcysteine (NAC) đường tĩnh mạch nếu nghi ngờ ngộ độc Paracetamol (không chờ kết quả xét nghiệm định lượng).',
          'Khôi phục huyết động học khẩn cấp nếu có tụt huyết áp, sốc tim hoặc sốc nhiễm trùng.'
        ],
        furtherInvestigations: [
          'Định lượng nồng độ Paracetamol huyết thanh, Khí máu động mạch (đánh giá toan lactic), Lactate máu, Khám độc chất nước tiểu.',
          'Siêu âm Doppler mạch máu gan cấp cứu.',
          'Hội chứng virus: IgM HAV, HBsAg, IgM anti-HBc, Anti-HCV, HSV, EBV, CMV serology/PCR.',
          'Xem xét sinh thiết gan chẩn đoán nếu tình trạng lâm sàng ổn định và bilan không xâm lấn không tìm ra nguyên nhân.'
        ],
        keyDiagnosticPearls: [
          'Trong thiếu máu cục bộ gan (Shock Liver), AST thường tăng cao hơn ALT và LDH tăng vọt gấp hàng chục lần; men gan giảm rất nhanh sau khi hồi sức tưới máu tốt.',
          'Độ cao tuyệt đối của transaminase không tỷ lệ thuận với khả năng sống còn; sự tụt giảm đột ngột của men gan đi kèm INR tiếp tục kéo dài và Bilirubin tăng vọt là dấu hiệu cạn kiệt tế bào gan (hoại tử toàn bộ).'
        ]
      }
    ]
  },
  {
    id: 'algo-cholestasis',
    title: 'Lưu Đồ Tiếp Cận Men Ứ Mật (Alkaline Phosphatase & GGT)',
    subtitle: 'Xác nhận nguồn gốc gan, định hướng tắc mật ngoài gan và các bệnh ứ mật trong gan',
    sourceGuideline: 'ACG Guideline & WHO Session 4',
    overview: 'Alkaline Phosphatase (ALP) tăng gợi ý tổn thương đường mật hoặc ứ mật. Lưu đồ chuẩn giúp phân định chính xác nguồn gốc cơ quan và lựa chọn kỹ thuật hình ảnh thích hợp.',
    branches: [
      {
        id: 'alp-isolated',
        title: 'Bước 1: Khẳng định nguồn gốc gan của ALP',
        conditionDescription: 'ALP tăng đơn độc trong khi ALT, AST và Bilirubin hoàn toàn bình thường.',
        color: 'sky',
        clinicalActions: [
          'Chỉ định xét nghiệm GGT (Gamma-Glutamyl Transferase) hoặc 5\'-Nucleotidase.',
          'Nếu GGT Bình Thường: ALP KHÔNG có nguồn gốc từ gan. Tìm nguyên nhân từ xương (bệnh Paget, di căn xương, nhuyễn xương do thiếu vitamin D), nhau thai (mang thai 3 tháng cuối) hoặc tăng sinh lý tuổi dậy thì.',
          'Nếu GGT Tăng Cao: Khẳng định ALP có nguồn gốc từ gan mật. Chuyển sang Bước 2 (Siêu âm gan mật).'
        ],
        furtherInvestigations: [
          'Nếu nghi ngờ nguồn gốc xương: Định lượng Canxi, Phospho máu, 25-OH Vitamin D, PTH, Chụp xạ hình xương nếu nghi ngờ u di căn.'
        ],
        keyDiagnosticPearls: [
          'GGT không có trong mô xương, là chìa khóa phân biệt rẻ tiền và đáng tin cậy nhất.'
        ]
      },
      {
        id: 'biliary-dilated',
        title: 'Bước 2A: Siêu âm thấy đường mật dãn (Tắc mật ngoài gan)',
        conditionDescription: 'Đường mật trong gan hoặc ngoài gan dãn (ống mật chủ > 6-7mm ở người trẻ hoặc > 10mm sau cắt túi mật).',
        color: 'amber',
        clinicalActions: [
          'Chẩn đoán: Tắc nghẽn cơ học đường mật.',
          'Đánh giá tam chứng Charcot (Đau HSP + Sốt + Vàng da) để phát hiện Viêm đường mật cấp nhiễm trùng.',
          'Chỉ định hình ảnh học độ phân giải cao: Chụp cộng hưởng từ mật tụy (MRCP) hoặc CT ngực bụng đa dãy có cản quang.'
        ],
        furtherInvestigations: [
          'Nội soi mật tụy ngược dòng (ERCP): Vừa chẩn đoán vừa can thiệp lấy sỏi, cắt cơ vòng Oddi hoặc đặt stent giải áp đường mật.',
          'Nội soi siêu âm (EUS): Nhạy cảm tối đa với sỏi bùn ống mật chủ đoạn thấp và khối u bóng Vater / đầu tụy.'
        ],
        keyDiagnosticPearls: [
          'Sỏi mật là nguyên nhân lành tính phổ biến nhất; ở người cao tuổi sút cân không đau bụng phải đặc biệt cảnh giác u đầu tụy hoặc ung thư đường mật (Klatskin).'
        ]
      },
      {
        id: 'biliary-nondilated',
        title: 'Bước 2B: Siêu âm đường mật không dãn (Ứ mật trong gan)',
        conditionDescription: 'Nhu mô gan đồng nhất hoặc thô nhẹ, hệ thống đường mật hoàn toàn không có dấu hiệu dãn nở.',
        color: 'indigo',
        clinicalActions: [
          'Rà soát ngay tiền sử dùng thuốc: Amoxicillin-Clavulanate, anabolic steroids, thuốc tránh thai, TMP-SMZ.',
          'Xét nghiệm tự kháng thể: Kháng thể kháng ty thể (AMA) để chẩn đoán Viêm đường mật tiên phát (PBC).',
          'Khảo sát Viêm xơ đường mật tiên phát (PSC): Khai thác bệnh sử viêm loét đại tràng (IBD), xét nghiệm IgG4.'
        ],
        furtherInvestigations: [
          'Nếu AMA (+): Chẩn đoán xác định PBC nếu ALP > 1.5x ULN (không cần sinh thiết gan). Khởi trị ngay Ursodeoxycholic acid (UDCA).',
          'Nếu AMA (-) và nghi ngờ PSC hoặc bệnh đường mật nhỏ: Chỉ định MRCP đánh giá hình thái cây mật (tìm hình ảnh hẹp dãn chuỗi hạt).',
          'Cân nhắc sinh thiết gan nếu AMA(-) và ALP vẫn tăng >2x kéo dài để loại trừ PBC âm tính với AMA, bệnh u hạt (Sarcoidosis), thoái hóa amyloid hoặc hội chứng biến mất đường mật.'
        ],
        keyDiagnosticPearls: [
          'Phụ nữ trung niên có ngứa da dai dẳng + ALP tăng + AMA(+) là bộ ba chẩn đoán xác định PBC.'
        ]
      }
    ]
  },
  {
    id: 'algo-bilirubin',
    title: 'Lưu Đồ Tiếp Cận Tăng Bilirubin & Vàng Da',
    subtitle: 'Phân đoạn Bilirubin gián tiếp vs liên hợp và cây quyết định chẩn đoán',
    sourceGuideline: 'WHO Training Session 4 & ACG Guideline',
    overview: 'Bước đầu tiên và quan trọng nhất khi tiếp cận bệnh nhân vàng da hoặc tăng bilirubin là phân đoạn (Fractionation) thành Bilirubin Trực tiếp (liên hợp) và Gián tiếp (tự do).',
    branches: [
      {
        id: 'bili-unconjugated',
        title: 'Ưu thế Bilirubin Gián tiếp / Tự do (<20% liên hợp)',
        conditionDescription: 'Bilirubin toàn phần tăng, trong đó Bilirubin trực tiếp chỉ chiếm dưới 20% tổng lượng.',
        color: 'amber',
        clinicalActions: [
          'Loại trừ ngay hiện tượng tán huyết (Hemolysis): Kiểm tra tổng phân tích tế bào máu, Haptoglobin, LDH, hồng cầu lưới, nghiệm pháp Coombs.',
          'Nếu có bằng chứng tán huyết: Chuyển khám chuyên khoa Huyết học tìm nguyên nhân (Thalassemia, thiếu men G6PD, tán huyết miễn dịch).',
          'Nếu KHÔNG có tán huyết và các men gan (ALT, AST, ALP, GGT) hoàn toàn bình thường: Chẩn đoán Hội chứng Gilbert.'
        ],
        furtherInvestigations: [
          'Hội chứng Gilbert: Bilirubin thường < 3 - 4 mg/dL, tăng lên khi nhịn ăn hoặc stress. Có thể làm xét nghiệm di truyền gen UGT1A1 nếu cần xác nhận pháp lý/bảo hiểm.',
          'Hội chứng Crigler-Najjar (rất hiếm ở người lớn): Thường khởi phát nặng từ giai đoạn sơ sinh.'
        ],
        keyDiagnosticPearls: [
          'Bilirubin gián tiếp không tan trong nước, không qua nước tiểu (nước tiểu không có sắc tố mật).'
        ]
      },
      {
        id: 'bili-conjugated',
        title: 'Ưu thế Bilirubin Trực tiếp / Liên hợp (>50% liên hợp)',
        conditionDescription: 'Bilirubin toàn phần tăng, trong đó Bilirubin trực tiếp chiếm trên 50%.',
        color: 'rose',
        clinicalActions: [
          'Đây là dấu hiệu chắc chắn của bệnh lý tế bào gan hoặc tắc nghẽn đường dẫn mật (Biliary or Hepatocellular disease).',
          'Bilirubin trực tiếp tan trong nước, thải qua nước tiểu làm nước tiểu có màu vàng sẫm sủi bọt vàng (Bilirubinuria).',
          'Chỉ định ngay Siêu âm ổ bụng để phân biệt tắc nghẽn cơ học đường mật (sỏi, u) với bệnh lý nhu mô gan.'
        ],
        furtherInvestigations: [
          'Nếu đường mật dãn: MRCP hoặc can thiệp ERCP.',
          'Nếu đường mật không dãn: Đánh giá tổn thương tế bào gan nặng (viêm gan virus, viêm gan do rượu, xơ gan mất bù, DILI).',
          'Nếu men gan hoàn toàn bình thường: Cân nhắc hội chứng di truyền hiếm gặp Dubin-Johnson hoặc Rotor.'
        ],
        keyDiagnosticPearls: [
          'Nồng độ Bilirubin toàn phần có thể vượt quá 30 mg/dL trong xơ gan mất bù có suy thận hoặc viêm gan rượu thể tối nặng.'
        ]
      }
    ]
  },
  {
    id: 'algo-deritis',
    title: 'Lưu Đồ Tiếp Cận Động Học Tỷ Số De Ritis (AST / ALT)',
    subtitle: 'Phân định bào tương vs ty thể, thời gian bán thải t½ và phân tầng 10 bệnh cảnh theo Botros & Sikaris (2013)',
    sourceGuideline: 'Clin Biochem Rev 2013; 34:117-130 & ACG Guidelines 2017',
    overview: 'Nghiên cứu kinh điển của Fernando De Ritis (1957) và tổng kết hiện đại của Sikaris (2013) khẳng định: tỷ số AST/ALT là công cụ sinh hóa vô giá giúp phân biệt nguồn gốc tế bào học (bào tương vs ty thể), phát hiện sớm xơ gan tiến triển, chẩn đoán bệnh gan do rượu và cảnh báo tiêu cơ vân ngoài gan.',
    branches: [
      {
        id: 'deritis-low',
        title: 'Tỷ số De Ritis < 1.0 (Ưu thế ALT)',
        conditionDescription: 'ALT cao hơn AST (thường dao động 0.4 - 0.8). Gặp trong tổn thương bào tương tế bào gan cấp tính.',
        color: 'emerald',
        clinicalActions: [
          'Nhận định: Tổn thương màng tế bào gan giải phóng ALT bào tương; ALT có thời gian bán hủy dài (~47h so với 17h của AST) nên duy trì nồng độ cao trong máu.',
          'Bệnh cảnh điển hình: Viêm gan virus cấp (HAV, HBV, HCV), viêm gan nhiễm mỡ chuyển hóa (MASLD) giai đoạn đầu hoặc tắc mật cấp 24 giờ đầu.',
          'Bilan đề xuất: HBsAg, anti-HCV, IgM anti-HAV, siêu âm gan kiểm tra độ nhiễm mỡ.'
        ],
        furtherInvestigations: [
          'Định lượng tải lượng HBV DNA, HCV RNA nếu có bằng chứng nhiễm virus.',
          'Đo độ đàn hồi gan FibroScan đánh giá CAP.'
        ],
        keyDiagnosticPearls: [
          'Trong viêm gan virus cấp, De Ritis < 1.0 là quy luật; nếu đột ngột đảo ngược > 1.5 - 2.0 cần cảnh báo nguy cơ hoại tử tế bào gan ồ ạt chuyển sang suy gan cấp!'
        ]
      },
      {
        id: 'deritis-transition',
        title: 'Nghịch đảo tỷ số: De Ritis vượt ngưỡng > 1.0',
        conditionDescription: 'Trong bệnh gan mạn (HBV, HCV, MASLD), AST từ thấp hơn ALT dần tăng vượt qua ALT (De Ritis > 1.0).',
        color: 'amber',
        clinicalActions: [
          'CẢNH BÁO XƠ HÓA TIẾN TRIỂN: Tỷ số AST/ALT > 1.0 ở bệnh nhân viêm gan mạn tính là chỉ điểm rất nhạy của xơ hóa gan nặng (F3) hoặc xơ gan (F4).',
          'Cơ chế sinh lý bệnh: (1) Suy giảm các thụ thể mannose trên tế bào nội mô xoang gan làm giảm độ thanh thải AST khỏi tuần hoàn; (2) Tổn thương ty thể mAST tích tụ; (3) Giảm tổng hợp ALT do mô gan xơ teo.',
          'Tính ngay thang điểm không xâm lấn FIB-4 và APRI.'
        ],
        furtherInvestigations: [
          'Đo độ đàn hồi mô gan (VCTE/FibroScan): xác định độ cứng mô gan (kPa).',
          'Nội soi thực quản dạ dày tầm soát giãn tĩnh mạch thực quản nếu nghi ngờ xơ gan (FIB-4 > 2.67 hoặc tiểu cầu < 150 x10^9/L).'
        ],
        keyDiagnosticPearls: [
          'Sự đảo ngược AST/ALT > 1.0 có giá trị tiên lượng xơ gan tương đương với nhiều xét nghiệm đắt tiền.'
        ]
      },
      {
        id: 'deritis-high',
        title: 'Tỷ số De Ritis ≥ 2.0 (Ưu thế AST kinh điển bệnh rượu)',
        conditionDescription: 'AST tăng gấp đôi hoặc gấp ba lần ALT, trong khi mức AST tuyệt đối thường < 400-500 U/L.',
        color: 'rose',
        clinicalActions: [
          'Chẩn đoán hướng tới: Bệnh gan do rượu (Alcoholic Liver Disease / Alcoholic Hepatitis). Độ nhạy ~70%, độ đặc hiệu >90%.',
          'Cơ chế: (1) Cồn gây độc trực tiếp màng ty thể làm phóng thích mAST (chiếm 80% AST gan); (2) Thiếu hụt Pyridoxal-5-phosphate (Vitamin B6) ở người nghiện rượu ức chế tổng hợp ALT nhiều hơn AST; (3) Giảm thanh thải AST.',
          'Tính chỉ số Maddrey Discriminant Function (DF): Nếu DF ≥ 32 -> Viêm gan do rượu thể nặng có chỉ định Corticosteroid.'
        ],
        furtherInvestigations: [
          'Định lượng Phosphatidylethanol (PEth) hoặc EtG nếu cần chứng cứ khách quan về lạm dụng rượu.',
          'Bổ sung Thiamine (Vitamin B1) liều cao đường tĩnh mạch trước khi truyền đường để ngừa hội chứng Wernicke-Korsakoff.'
        ],
        keyDiagnosticPearls: [
          'Nếu De Ritis > 2.0 nhưng AST > 500-1000 U/L: Phải nghi ngờ có ngộ độc Paracetamol đi kèm trên cơ địa nghiện rượu, hoặc tổn thương gan thiếu máu cục bộ!'
        ]
      },
      {
        id: 'deritis-extrahepatic',
        title: 'De Ritis cực cao do Nguồn Gốc Ngoài Gan (Tiêu cơ vân / Tập luyện nặng)',
        conditionDescription: 'AST tăng rất cao (vài trăm đến hàng nghìn U/L) trong khi ALT chỉ tăng nhẹ hoặc bình thường (De Ritis > 3 - 6), ALP và Bilirubin bình thường.',
        color: 'indigo',
        clinicalActions: [
          'Loại trừ tổn thương gan nguyên phát: Đây là "bẫy sinh thái học" kinh điển!',
          'Cơ vân chứa nồng độ AST cực lớn (5000 U/g so với ALT chỉ 300 U/g). Tiêu cơ vân do vận động nặng, chạy marathon, chấn thương, co giật hoặc dùng Statin giải phóng lượng lớn AST.',
          'Chỉ định ngay Creatine Kinase (CK) toàn phần, Myoglobin niệu và tổng phân tích nước tiểu.'
        ],
        furtherInvestigations: [
          'Nếu CK tăng cao (> 1000 đến hàng chục nghìn U/L): Chẩn đoán Tiêu cơ vân (Rhabdomyolysis).',
          'Nếu CK bình thường và bệnh nhân hoàn toàn không triệu chứng: Làm nghiệm pháp kết tủa PEG để tìm phức hợp kháng thể Macro-AST lành tính.'
        ],
        keyDiagnosticPearls: [
          'Không bao giờ kết luận tổn thương gan cấp nếu chỉ dựa vào AST tăng cao đơn độc mà không kiểm tra ALT và CK!'
        ]
      }
    ]
  },
  {
    id: 'algo-dili',
    title: 'Lưu Đồ Tổn Thương Gan Do Thuốc (DILI) & Định Luật Hy',
    subtitle: 'Phân loại theo chỉ số R, đánh giá nguy cơ tử vong theo tiêu chí Hy\'s Law (ACG 2017 & FDA)',
    sourceGuideline: 'ACG Clinical Guideline: Evaluation of Abnormal Liver Chemistries 2017 & FDA Guidance',
    overview: 'Tổn thương gan do thuốc (Drug-Induced Liver Injury - DILI) là nguyên nhân hàng đầu gây suy gan cấp tại các nước phát triển. Phân định tổn thương theo chỉ số R và đánh giá định luật Hy giúp cứu sống người bệnh kịp thời.',
    branches: [
      {
        id: 'dili-hys-law-branch',
        title: 'Cảnh báo Định luật Hy (Hy\'s Law Alert)',
        conditionDescription: 'ALT ≥ 3x ULN kết hợp Bilirubin toàn phần ≥ 2.0 mg/dL do tổn thương tế bào gan (R > 3) mà không có ứ mật ban đầu (ALP < 2x ULN).',
        color: 'rose',
        clinicalActions: [
          'Nguy cơ tử vong hoặc cần ghép gan lên tới 10% (Tỷ lệ tử vong kinh điển của Hy Zimmerman).',
          'Dừng ngay lập tức tất cả các thuốc kê đơn, thuốc OTC, thực phẩm chức năng và thảo dược nghi ngờ.',
          'Theo dõi sát INR, đường huyết mao mạch, tri giác mỗi 12-24 giờ để phát hiện suy gan cấp (ALF).'
        ],
        furtherInvestigations: [
          'Tra cứu cơ sở dữ liệu quốc tế LiverTox (livertox.nih.gov) để xác định điểm RUCAM và độc tính thuốc.',
          'Đo nồng độ Acetaminophen huyết thanh khẩn cấp.'
        ],
        keyDiagnosticPearls: [
          'Hy\'s Law là tiêu chuẩn vàng được FDA sử dụng để đánh giá độ an toàn gan của các thuốc mới trong thử nghiệm lâm sàng.'
        ]
      },
      {
        id: 'dili-patterns',
        title: 'Phân loại DILI theo kiểu tổn thương sinh hóa (R-Ratio)',
        conditionDescription: 'Tính chỉ số R = (ALT/ULN) / (ALP/ULN) tại thời điểm khởi phát tổn thương.',
        color: 'sky',
        clinicalActions: [
          'R > 5 (Thể tế bào gan): Hay gặp do Isoniazid, Paracetamol, Nitrofurantoin, Statin, Thảo dược giảm cân.',
          'R < 2 (Thể ứ mật): Hay gặp do Amoxicillin-Clavulanate, Steroid đồng hóa, Thuốc tránh thai uống, Erythromycin.',
          '2 ≤ R ≤ 5 (Thể hỗn hợp): Hay gặp do TMP-SMZ, Phenytoin, Kháng sinh Carbapenem.'
        ],
        furtherInvestigations: [
          'Theo dõi động học thoái lui của men gan sau khi ngừng thuốc: Thể tế bào gan thường giảm 50% trong vòng 1-2 tuần; thể ứ mật có thể mất 3-6 tháng mới về bình thường.'
        ],
        keyDiagnosticPearls: [
          'DILI do Amoxicillin-Clavulanate thường khởi phát trễ sau khi đã kết thúc đợt thuốc 1 đến 4 tuần.'
        ]
      }
    ]
  },
  {
    id: 'algo-sld-steatotic',
    title: 'Lưu Đồ Phân Loại Bệnh Gan Nhiễm Mỡ (SLD) & Đánh Giá Xơ Hóa (MASLD vs MetALD vs ALD)',
    subtitle: 'Đồng thuận danh pháp quốc tế đa hội (Delphi Consensus) & Khuyến cáo thực hành BSG 2018 / BMJ 2025',
    sourceGuideline: 'BSG Guidelines on Abnormal Liver Blood Tests (Gut 2018) & BMJ Practice Pointer 2025',
    overview: 'Danh pháp Steatotic Liver Disease (SLD) phân định chính xác vai trò của yếu tố tim mạch - chuyển hóa (Cardiometabolic) và mức độ tiêu thụ rượu bia (g/tuần) nhằm tránh kỳ thị và tối ưu hóa điều trị xơ hóa.',
    branches: [
      {
        id: 'sld-masld',
        title: 'Bệnh gan nhiễm mỡ chuyển hóa (MASLD / MASH)',
        conditionDescription: 'Nhiễm mỡ gan (siêu âm hoặc sinh thiết) + ít nhất 1 yếu tố chuyển hóa (BMI ≥ 23-25, ĐTĐ T2, tiền ĐTĐ, tăng huyết áp, tăng TG hoặc giảm HDL) + Uống rượu tối thiểu (< 140 g/tuần ở nữ, < 210 g/tuần ở nam).',
        color: 'emerald',
        clinicalActions: [
          'Tư vấn chế độ ăn Địa Trung Hải, hạn chế đường fructose và carbohydrate tinh chế.',
          'Vận động thể lực nhịp điệu ≥ 150 phút/tuần, đặt mục tiêu giảm cân 7 - 10% trọng lượng cơ thể.',
          'Tiếp tục Statin an toàn: Statin an toàn nếu ALT < 3x ULN, giúp giảm nguy cơ tim mạch (nguyên nhân tử vong hàng đầu ở MASLD).'
        ],
        furtherInvestigations: [
          'Tính ngay chỉ số FIB-4 hoặc NAFLD Fibrosis Score (NFS) tại tuyến ban đầu.',
          'Nếu FIB-4 < 1.30 (< 2.00 nếu ≥ 65 tuổi): Nguy cơ xơ hóa thấp, theo dõi định kỳ mỗi 2-3 năm tại y tế cơ sở.',
          'Nếu FIB-4 > 1.30 (hoặc > 2.00 nếu ≥ 65 tuổi): Đo độ đàn hồi thoáng qua (FibroScan / VCTE) hoặc chuyển chuyên khoa gan mật.'
        ],
        keyDiagnosticPearls: [
          'Tỷ số AST/ALT trong MASLD ban đầu thường < 1.0; nếu AST vượt ALT (De Ritis > 1.0) báo động xơ hóa đã tiến triển F3-F4.'
        ]
      },
      {
        id: 'sld-metald',
        title: 'Bệnh gan nhiễm mỡ chuyển hóa phối hợp rượu (MetALD)',
        conditionDescription: 'Thỏa tiêu chuẩn MASLD (yếu tố chuyển hóa) nhưng có mức tiêu thụ rượu trung bình (Nữ 140 - 350 g/tuần [20-50 g/ngày], Nam 210 - 420 g/tuần [30-60 g/ngày]).',
        color: 'amber',
        clinicalActions: [
          'Đây là nhóm nguy cơ cao do tác động cộng hưởng: Rượu gây độc ty thể phối hợp với kháng insulin làm xơ hóa gan tiến triển nhanh hơn gấp 2-3 lần MASLD đơn thuần.',
          'Can thiệp giảm hoặc kiêng rượu hoàn toàn; hỗ trợ tâm lý - hành vi nếu cần.',
          'Tối ưu hóa kiểm soát đường huyết và cân nặng.'
        ],
        furtherInvestigations: [
          'Xét nghiệm GGT và Bilan xơ hóa gan (FIB-4 / NFS, APRI, FibroScan).',
          'Đánh giá xơ hóa định kỳ hàng năm do tốc độ tiến triển xơ hóa nhanh.'
        ],
        keyDiagnosticPearls: [
          'Ở người uống rượu nguy cơ, GGT > 100 U/L là chỉ định bắt buộc phải tiến hành khảo sát giai đoạn xơ hóa gan ngay (theo BSG 2018).'
        ]
      },
      {
        id: 'sld-ald',
        title: 'Bệnh gan do rượu thuần túy (Alcohol-related Liver Disease - ALD)',
        conditionDescription: 'Tiêu thụ cồn vượt ngưỡng ALD: Nữ > 350 g/tuần (> 50 g/ngày), Nam > 420 g/tuần (> 60 g/ngày), hoặc điểm sàng lọc AUDIT-C ≥ 5 / AUDIT ≥ 8.',
        color: 'rose',
        clinicalActions: [
          'Cai rượu tuyệt đối là can thiệp cốt lõi quyết định tiên lượng sống còn.',
          'Đánh giá hội chứng cai rượu và nguy cơ mê sảng (Delirium Tremens).',
          'Bổ sung Thiamine (Vitamin B1) liều cao đường tĩnh mạch trước khi truyền glucose.'
        ],
        furtherInvestigations: [
          'Nếu vàng da nặng: Tính điểm Maddrey Discriminant Function (DF); nếu DF ≥ 32 cân nhắc Corticosteroid sau khi loại trừ nhiễm trùng.',
          'Đo INR, Bilirubin, Albumin và siêu âm bụng tầm soát tăng áp cửa (lách to, tuần hoàn bàng hệ).'
        ],
        keyDiagnosticPearls: [
          'Tỷ số AST:ALT > 2:1 ở mức transaminase < 500 U/L là dấu ấn đặc hiệu của ALD.'
        ]
      },
      {
        id: 'sld-fibrosis-tiering',
        title: 'Phân tầng nguy cơ xơ hóa theo FIB-4 & NFS hiệu chỉnh theo tuổi',
        conditionDescription: 'Áp dụng cho mọi bệnh nhân có gan thoái hóa mỡ hoặc men gan tăng mạn tính.',
        color: 'indigo',
        clinicalActions: [
          'Tuổi < 65 tuổi: FIB-4 < 1.30 hoặc NFS < -1.455 -> Nguy cơ xơ hóa thấp (NPV > 90%), theo dõi tại tuyến cơ sở.',
          'Tuổi ≥ 65 tuổi (Hiệu chỉnh theo BSG 2018): Ngưỡng loại trừ FIB-4 nâng lên < 2.00 và NFS < 0.12 để tránh chuyển tuyến quá mức!',
          'Vùng xám (FIB-4 1.30-2.67): Chỉ định đo độ đàn hồi mô gan (VCTE/FibroScan). Nếu LSM < 8.0 kPa -> an tâm theo dõi; nếu LSM ≥ 8.0 kPa -> chuyển chuyên khoa.',
          'Nguy cơ cao (FIB-4 > 2.67 hoặc NFS > 0.675): Chuyển khám chuyên khoa Tiêu hóa - Gan mật, tầm soát giãn tĩnh mạch thực quản và siêu âm sàng lọc HCC mỗi 6 tháng.'
        ],
        furtherInvestigations: [
          'Đo độ đàn hồi mô gan (FibroScan / Shear Wave Elastography).',
          'Nội soi thực quản dạ dày nếu có xơ gan nghi ngờ.'
        ],
        keyDiagnosticPearls: [
          'Không phụ thuộc đơn thuần vào men gan bình thường để loại trừ xơ hóa; tới 50% bệnh nhân xơ gan do MASLD có nồng độ ALT hoàn toàn nằm trong khoảng tham chiếu.'
        ]
      }
    ]
  }
];
