import { RucamAssessmentData, RucamScoreResult } from '../types/cdss';

export function calculateRucamScore(data: RucamAssessmentData): RucamScoreResult {
  let totalScore = 0;
  const breakdown: { domain: string; score: number; note: string }[] = [];

  const isHepatocellular = data.pattern === 'Hepatocellular';

  // 1. Time to onset
  let onsetScore = 0;
  let onsetNote = '';
  if (data.timeToOnset >= 5 && data.timeToOnset <= 90) {
    onsetScore = 2;
    onsetNote = 'Thời gian khởi phát từ 5 đến 90 ngày sau khi bắt đầu dùng thuốc (+2 điểm - Khung thời gian điển hình nhất của DILI)';
  } else if (data.timeToOnset < 5) {
    onsetScore = 1;
    onsetNote = 'Khởi phát rất sớm < 5 ngày (+1 điểm - Thường gặp khi đã có mẫn cảm trước đó)';
  } else {
    onsetScore = 1;
    onsetNote = 'Khởi phát muộn > 90 ngày (+1 điểm - Thường gặp ở các thuốc có cơ chế miễn dịch dị ứng tích lũy)';
  }

  // Bonus for cessation if applicable
  if (data.timeFromCessation !== undefined) {
    if (isHepatocellular && data.timeFromCessation <= 15) {
      onsetScore = Math.min(3, onsetScore + 1);
      onsetNote += ' & Khởi phát trong vòng ≤ 15 ngày sau khi ngưng thuốc';
    } else if (!isHepatocellular && data.timeFromCessation <= 30) {
      onsetScore = Math.min(3, onsetScore + 1);
      onsetNote += ' & Khởi phát trong vòng ≤ 30 ngày sau khi ngưng thuốc thể ứ mật';
    }
  }
  totalScore += onsetScore;
  breakdown.push({ domain: '1. Thời gian khởi phát (Time to Onset)', score: onsetScore, note: onsetNote });

  // 2. Course of ALT/ALP after cessation (Dechallenge)
  let dechallengeScore = 0;
  let dechallengeNote = '';
  const pct = data.dechallengeDecreasePct ?? 0;
  if (isHepatocellular) {
    if (pct >= 50) {
      dechallengeScore = 3;
      dechallengeNote = 'Men ALT giảm ≥ 50% so với đỉnh trong vòng 8-30 ngày sau khi ngưng thuốc (+3 điểm - Dechallenge rất thuận lợi)';
    } else if (pct >= 20) {
      dechallengeScore = 1;
      dechallengeNote = 'Men ALT giảm từ 20-50% sau ngưng thuốc (+1 điểm)';
    } else if (pct < 0) {
      dechallengeScore = -2;
      dechallengeNote = 'Men ALT tiếp tục tăng hoặc không giảm sau khi đã ngưng thuốc (-2 điểm)';
    } else {
      dechallengeScore = 0;
      dechallengeNote = 'Men ALT giảm chậm hoặc chưa đủ thời gian đánh giá (0 điểm)';
    }
  } else {
    // Cholestatic or Mixed
    if (pct >= 50) {
      dechallengeScore = 2;
      dechallengeNote = 'Men ALP / Bilirubin giảm ≥ 50% trong vòng 180 ngày (+2 điểm - Ứ mật thoái lui chậm)';
    } else if (pct < 0) {
      dechallengeScore = -2;
      dechallengeNote = 'Men ALP tiếp tục tăng sau ngưng thuốc (-2 điểm)';
    } else {
      dechallengeScore = 0;
      dechallengeNote = 'Động học thoái lui trung gian (0 điểm)';
    }
  }
  totalScore += dechallengeScore;
  breakdown.push({ domain: '2. Diễn tiến sau ngưng thuốc (Dechallenge Course)', score: dechallengeScore, note: dechallengeNote });

  // 3. Risk Factors (Alcohol, Age >= 55, Pregnancy)
  let riskScore = 0;
  const riskNotes: string[] = [];
  if (data.alcoholIntakeSignificant) {
    riskScore += 1;
    riskNotes.push('Tiêu thụ rượu đáng kể làm tăng cảm ứng enzym P450 (+1)');
  }
  if (data.ageOver55) {
    riskScore += 1;
    riskNotes.push('Tuổi ≥ 55 tuổi (+1)');
  }
  if (!isHepatocellular && data.pregnancy) {
    riskScore += 1;
    riskNotes.push('Mang thai ở thể ứ mật (+1)');
  }
  riskScore = Math.min(2, riskScore);
  totalScore += riskScore;
  breakdown.push({
    domain: '3. Yếu tố nguy cơ cơ địa (Risk Factors: Rượu, Tuổi, Thai kỳ)',
    score: riskScore,
    note: riskNotes.length > 0 ? riskNotes.join(', ') : 'Không có yếu tố nguy cơ (0 điểm)'
  });

  // 4. Concomitant Drugs
  let concomitantScore = 0;
  let concomitantNote = '';
  if (data.concomitantDrugsCount === 0) {
    concomitantScore = 0;
    concomitantNote = 'Không dùng thuốc đồng thời (0 điểm)';
  } else if (data.concomitantDrugsCount === 1) {
    concomitantScore = 0;
    concomitantNote = 'Có 1 thuốc dùng kèm nhưng ít độc tính hơn hoặc thời gian không tương thích (0 điểm)';
  } else {
    concomitantScore = -2;
    concomitantNote = `Có ${data.concomitantDrugsCount} thuốc đồng thời có khả năng gây độc gan (-2 điểm do khó phân định trách nhiệm)`;
  }
  totalScore += concomitantScore;
  breakdown.push({ domain: '5. Thuốc dùng đồng thời (Concomitant Drugs)', score: concomitantScore, note: concomitantNote });

  // 5. Search for Alternative Non-Drug Causes
  let altCausesScore = 0;
  let altCausesNote = '';
  if (data.alternativeCausesRuledOut === 'full') {
    altCausesScore = 2;
    altCausesNote = 'Đã loại trừ đầy đủ tất cả nguyên nhân: HAV, HBV, HCV, Tự miễn (ANA/ASMA/IgG), Siêu âm đường mật, Thiếu máu cục bộ (+2 điểm)';
  } else if (data.alternativeCausesRuledOut === 'partial') {
    altCausesScore = 1;
    altCausesNote = 'Đã loại trừ được các nguyên nhân virus chính nhưng chưa hoàn tất toàn bộ bilan (+1 điểm)';
  } else {
    altCausesScore = -3;
    altCausesNote = 'Tìm thấy bằng chứng mạnh của nguyên nhân khác như tắc mật cơ học, bùng phát viêm gan B hoặc sốc tim (-3 điểm)';
  }
  totalScore += altCausesScore;
  breakdown.push({ domain: '6. Loại trừ nguyên nhân ngoài thuốc (Alternative Causes)', score: altCausesScore, note: altCausesNote });

  // 6. Previous hepatotoxicity info
  let prevInfoScore = 0;
  let prevInfoNote = '';
  if (data.previousHepatotoxicityInLabel) {
    prevInfoScore = 2;
    prevInfoNote = 'Độc tính gan đã được ghi nhận chính thức trong Dược thư / Tờ hướng dẫn sử dụng của nhà sản xuất (+2 điểm)';
  } else if (data.previousHepatotoxicityPublished) {
    prevInfoScore = 1;
    prevInfoNote = 'Đã có các ca báo cáo trong y văn / cơ sở dữ liệu LiverTox (+1 điểm)';
  } else {
    prevInfoScore = 0;
    prevInfoNote = 'Thuốc chưa từng có báo cáo gây độc gan (0 điểm)';
  }
  totalScore += prevInfoScore;
  breakdown.push({ domain: '7. Dữ liệu độc tính gan đã biết (Previous Information)', score: prevInfoScore, note: prevInfoNote });

  // 7. Response to Unintentional Rechallenge
  let rechallengeScore = 0;
  let rechallengeNote = '';
  if (data.unintentionalRechallengeResult === 'positive') {
    rechallengeScore = 3;
    rechallengeNote = 'Tái sử dụng thuốc vô ý làm men gan tăng vọt gấp đôi trở lại (+3 điểm - Bằng chứng nhân quả cực mạnh)';
  } else if (data.unintentionalRechallengeResult === 'negative') {
    rechallengeScore = -2;
    rechallengeNote = 'Dùng lại thuốc mà men gan không tăng (-2 điểm)';
  } else {
    rechallengeScore = 0;
    rechallengeNote = 'Không thử nghiệm lại (0 điểm - Khuyến cáo không chủ động rechallenge vì nguy cơ đe dọa tính mạng)';
  }
  totalScore += rechallengeScore;
  breakdown.push({ domain: '8. Đáp ứng khi tái sử dụng (Rechallenge Response)', score: rechallengeScore, note: rechallengeNote });

  // Determine Category according to international consensus (Allison et al. 2023 Update)
  let causalityCategory: RucamScoreResult['causalityCategory'] = 'Có thể (3-5)';
  let clinicalAdvice = '';

  if (totalScore > 8) {
    causalityCategory = 'Rất chắc chắn (>8)';
    clinicalAdvice = 'Mức độ quan hệ nhân quả RẤT CHẮC CHẮN (Highly Probable). Chống chỉ định vĩnh viễn thuốc này và các dẫn xuất cùng nhóm cấu trúc hóa học. Báo cáo ADR lên Trung tâm Quốc gia về Thông tin thuốc và Theo dõi phản ứng có hại.';
  } else if (totalScore >= 6) {
    causalityCategory = 'Khả năng cao (6-8)';
    clinicalAdvice = 'Mức độ quan hệ nhân quả KHẢ NĂNG CAO (Probable). Ngưng thuốc ngay, ghi nhận vào tiền sử dị ứng thuốc của bệnh nhân. Tránh dùng lại.';
  } else if (totalScore >= 3) {
    causalityCategory = 'Có thể (3-5)';
    clinicalAdvice = 'Tổn thương gan CÓ THỂ do thuốc (Possible). Cần tiếp tục theo dõi động học hạ men sau khi ngừng thuốc và hoàn tất các xét nghiệm loại trừ nguyên nhân khác.';
  } else if (totalScore >= 1) {
    causalityCategory = 'Ít khả năng (1-2)';
    clinicalAdvice = 'ÍT KHẢ NĂNG do thuốc (Unlikely). Ưu tiên tìm kiếm các nguyên nhân bệnh lý nguyên phát khác (sỏi mật, virus bùng phát, tự miễn).';
  } else {
    causalityCategory = 'Loại trừ (≤0)';
    clinicalAdvice = 'ĐÃ LOẠI TRỪ DILI (Excluded). Bằng chứng lâm sàng hướng về bệnh lý nguyên phát khác.';
  }

  // Allison et al. 2023 Genetic Susceptibility Table
  const hlaGeneticAssociations = [
    { drug: 'Flucloxacillin', allele: 'HLA-B*57:01', oddsRatio: '80.6 (Thể ứ mật)' },
    { drug: 'Amoxicillin-Clavulanate', allele: 'HLA-DRB1*15:01 & HLA-DQB1*06:02', oddsRatio: '9.3 (Tổn thương sau ngưng thuốc 2-4 tuần)' },
    { drug: 'Allopurinol', allele: 'HLA-B*58:01', oddsRatio: '> 80 (DILI kèm DRESS / Steven-Johnson)' },
    { drug: 'Ticlopidine', allele: 'HLA-A*33:03', oddsRatio: '36.5 (Tổn thương tế bào gan nặng)' },
    { drug: 'Minocycline', allele: 'HLA-B*35:02', oddsRatio: '29.6 (Viêm gan dạng tự miễn do thuốc)' },
    { drug: 'Carbamazepine', allele: 'HLA-A*31:01 & HLA-B*15:02', oddsRatio: '12.4 (Phản ứng tăng cảm)' }
  ];

  return {
    totalScore,
    causalityCategory,
    breakdown,
    clinicalAdvice,
    hlaGeneticAssociations
  };
}
