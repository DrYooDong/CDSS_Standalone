import { PatientLabs, CDSSAnalysis, InjuryPattern, ElevationSeverity, CDSSRiskTier, DeRitisPathology } from '../types/cdss';

export function calculateAnalysis(labs: PatientLabs): CDSSAnalysis {
  const altUln = labs.altUln || (labs.gender === 'male' ? 33 : 25);
  const astUln = labs.astUln || (labs.gender === 'male' ? 33 : 25);
  const alpUln = labs.alpUln || 120;
  const ggtUln = labs.ggtUln || (labs.gender === 'male' ? 60 : 40);

  const altMultiples = Number((labs.alt / altUln).toFixed(2));
  const astMultiples = Number((labs.ast / astUln).toFixed(2));
  const alpMultiples = Number((labs.alp / alpUln).toFixed(2));

  // R ratio calculation: (ALT / ULN) / (ALP / ULN) - ACG 2017 & AASLD standard
  const rRatio = alpMultiples > 0 ? Number((altMultiples / alpMultiples).toFixed(2)) : 0;

  // De Ritis ratio: AST / ALT - Botros & Sikaris (2013)
  const deRitisRatio = labs.alt > 0 ? Number((labs.ast / labs.alt).toFixed(2)) : 0;

  // Bilirubin fractionation
  const conjugatedPercent = labs.totalBilirubin > 0 
    ? Number(((labs.directBilirubin / labs.totalBilirubin) * 100).toFixed(1)) 
    : 0;
  const isConjugatedPredominant = conjugatedPercent >= 50;
  const isUnconjugatedPredominant = conjugatedPercent < 20 && labs.totalBilirubin > 1.2;

  // Severity evaluation (based on max transaminase) according to ACG 2017
  const maxTransaminase = Math.max(labs.alt, labs.ast);
  const maxMultiple = Math.max(altMultiples, astMultiples);

  let severity: ElevationSeverity = 'Normal';
  if (maxTransaminase > 10000) {
    severity = 'Massive (>10,000 U/L)';
  } else if (maxMultiple > 15) {
    severity = 'Severe (>15x ULN)';
  } else if (maxMultiple >= 5) {
    severity = 'Moderate (5-15x ULN)';
  } else if (maxMultiple >= 2) {
    severity = 'Mild (2-5x ULN)';
  } else if (maxMultiple > 1) {
    severity = 'Borderline (<2x ULN)';
  }

  // Determine Pattern of Injury (ACG 2017 classification)
  let pattern: InjuryPattern = 'Normal / Borderline';
  const isTransaminaseElevated = altMultiples > 1 || astMultiples > 1;
  const isAlpElevated = alpMultiples > 1;
  const isBilirubinElevated = labs.totalBilirubin > 1.2;

  if (isBilirubinElevated && !isTransaminaseElevated && !isAlpElevated) {
    pattern = 'Isolated Hyperbilirubinemia';
  } else if (isTransaminaseElevated || isAlpElevated) {
    if (rRatio > 5) {
      pattern = 'Hepatocellular';
    } else if (rRatio < 2 && isAlpElevated) {
      pattern = 'Cholestatic';
    } else if (rRatio >= 2 && rRatio <= 5) {
      pattern = 'Mixed';
    } else if (isTransaminaseElevated && !isAlpElevated) {
      pattern = 'Hepatocellular';
    } else if (isAlpElevated && !isTransaminaseElevated) {
      pattern = 'Cholestatic';
    }
  }

  // Isolated ALP origin assessment
  let isolatedAlpOrigin: CDSSAnalysis['isolatedAlpOrigin'];
  if (alpMultiples > 1.0 && !isTransaminaseElevated) {
    if (labs.ggt !== undefined) {
      if (labs.ggt > ggtUln) {
        isolatedAlpOrigin = 'hepatic_confirmed';
      } else {
        isolatedAlpOrigin = 'suspect_bone_or_other';
      }
    } else {
      isolatedAlpOrigin = 'indeterminate';
    }
  }

  // Extrahepatic muscle / non-hepatic AST assessment (Botros & Sikaris 2013)
  const isCkHigh = Boolean(labs.ck && labs.ck > 1000);
  const isAstDisproportionate = (labs.ast > 150 && labs.ast > labs.alt * 2.5 && alpMultiples <= 1.2);
  const rhabdoWarning = Boolean(isCkHigh || (isAstDisproportionate && labs.strenuousExercise));
  const extrahepaticAstWarning = Boolean(
    rhabdoWarning || (labs.ast > astUln * 2 && labs.alt <= altUln * 1.2 && alpMultiples <= 1.1)
  );

  // Wilson Disease Screening Index (ACG 2017: AST/ALT > 2.2 AND ALP/Total Bilirubin < 4.0)
  const alpToBilirubinRatio = labs.totalBilirubin > 0 ? Number((labs.alp / labs.totalBilirubin).toFixed(2)) : undefined;
  const isWilsonTriggered = Boolean(
    labs.alt > 0 &&
    deRitisRatio > 2.2 &&
    alpToBilirubinRatio !== undefined &&
    alpToBilirubinRatio < 4.0 &&
    labs.totalBilirubin >= 2.0 &&
    (labs.age === undefined || labs.age <= 55)
  );
  const wilsonIndex = {
    isTriggered: isWilsonTriggered,
    astAltRatio: deRitisRatio,
    alpBilRatio: alpToBilirubinRatio,
    note: isWilsonTriggered 
      ? 'Dấu hiệu cảnh báo bùng phát Wilson (ACG 2017): AST/ALT > 2.2 kết hợp ALP/Bilirubin < 4.0 ở bệnh nhân vàng da. Độ nhạy và độ đặc hiệu ~100% cho suy gan cấp do bệnh Wilson!'
      : 'Tỷ số ALP/Bilirubin và AST/ALT không thỏa tiêu chuẩn kinh điển của suy gan cấp do Wilson.'
  };

  // Hy's Law Warning (DILI criterion: ALT >= 3x ULN + Total Bilirubin >= 2.0 mg/dL without initial cholestasis)
  const hysLawWarning = Boolean(
    altMultiples >= 3.0 && 
    labs.totalBilirubin >= 2.0 && 
    (pattern === 'Hepatocellular' || rRatio > 3.0) &&
    alpMultiples < 2.0
  );

  // Maddrey Discriminant Function (DF) for Alcoholic Hepatitis: 4.6 * (PT - PTcontrol) + Total Bilirubin
  let maddreyScore: number | undefined;
  let maddreySevere: boolean | undefined;
  const isAlcoholHistory = Boolean(
    (labs.alcoholIntake && (
      (labs.gender === 'male' && labs.alcoholIntake > 210) || 
      (labs.gender === 'female' && labs.alcoholIntake > 140)
    )) ||
    (deRitisRatio >= 2.0 && labs.ast < 500 && (labs.ggt || 0) > 100)
  );

  if (labs.inr && labs.inr > 0 && labs.totalBilirubin > 0 && isAlcoholHistory) {
    // Convert INR to estimated delta PT seconds: delta PT ~ (INR - 1.0) * 12
    const deltaPT = Math.max(0, (labs.inr - 1.0) * 12);
    maddreyScore = Number((4.6 * deltaPT + labs.totalBilirubin).toFixed(1));
    maddreySevere = maddreyScore >= 32;
  }

  // De Ritis Pathophysiology analysis (Botros & Sikaris 2013)
  let deRitisPathology: DeRitisPathology;
  if (extrahepaticAstWarning) {
    deRitisPathology = {
      category: 'Nguồn gốc ngoài gan (Extrahepatic / Cơ vân)',
      clinicalMeaning: 'AST tăng vượt trội đơn độc gợi ý nguồn từ cơ vân (tiêu cơ, chấn thương, tập luyện nặng) hoặc hồng cầu (tán huyết), không phải hoại tử tế bào gan.',
      cellularMechanism: 'AST có nồng độ cực cao trong cơ vân (5000 U/g) và tim (7800 U/g) so với ALT (300 U/g). Khi cơ bắp tổn thương, AST và CK phóng thích ồ ạt trong khi ALT hầu như không biến đổi.',
      kineticsNote: 'Cần kiểm tra ngay CK, Troponin, Myoglobin niệu và loại trừ tan máu trong ống nghiệm.'
    };
  } else if (deRitisRatio >= 2.0 && maxTransaminase <= 500) {
    deRitisPathology = {
      category: 'Ưu thế AST kinh điển bệnh gan do rượu (Alcoholic Liver Injury)',
      clinicalMeaning: 'Tỷ số AST/ALT > 2.0 ở mức men < 500 U/L là dấu ấn đặc trưng của bệnh gan do rượu (ALD / Alcoholic Hepatitis) với độ nhạy ~70% và độ đặc hiệu >90%.',
      cellularMechanism: '(1) Ethanol gây độc trực tiếp màng ty thể làm phóng thích mAST (chiếm 80% tổng AST tế bào gan); (2) Thiếu Pyridoxine (Vitamin B6) ở người nghiện rượu làm ức chế tổng hợp ALT nhiều hơn AST; (3) Giảm thanh thải AST qua xoang gan.',
      kineticsNote: 'AST hiếm khi vượt quá 300-400 U/L và ALT hiếm khi vượt 200 U/L trong viêm gan do rượu đơn thuần.'
    };
  } else if (deRitisRatio > 1.0 && (pattern === 'Hepatocellular' || maxMultiple > 1)) {
    deRitisPathology = {
      category: 'Nghịch đảo tỷ số De Ritis (Chỉ điểm xơ hóa gan tiến triển)',
      clinicalMeaning: 'Trong viêm gan virus mạn hoặc gan nhiễm mỡ MASLD, khi tỷ số AST/ALT vượt qua ngưỡng 1.0, nguy cơ xơ hóa gan tiến triển (F3) hoặc xơ gan (F4) tăng vọt.',
      cellularMechanism: 'Tế bào nội mô xoang gan bị tổn thương xơ hóa làm giảm khả năng thanh thải AST qua thụ thể mannose; đồng thời tổn thương ty thể mAST tích tụ và gan xơ suy kiệt tổng hợp ALT.',
      kineticsNote: 'Khuyến cáo đo độ đàn hồi mô gan (VCTE/FibroScan) và tính chỉ số FIB-4/APRI.'
    };
  } else if (deRitisRatio < 1.0 && maxTransaminase > 200) {
    deRitisPathology = {
      category: 'Ưu thế ALT cấp tính (Acute Hepatocellular Injury / Viral)',
      clinicalMeaning: 'Điển hình của tổn thương hoại tử tế bào gan cấp do virus (HAV, HBV, HCV), gan thoái hóa mỡ sớm (MASLD), hoặc đợt hoại tử tế bào gan sớm.',
      cellularMechanism: 'ALT nằm hoàn toàn trong bào tương (Cytosol), dễ dàng thoát ra ngay khi màng tế bào thay đổi tính thấm; kèm thời gian bán thải của ALT dài gấp gần 3 lần AST (47h so với 17h) làm ALT tồn lưu cao trong huyết thanh.',
      kineticsNote: 'Thời gian bán hủy ALT ~47 giờ, AST ~17 giờ. ALT sẽ giảm chậm hơn AST trong giai đoạn hồi phục.'
    };
  } else {
    deRitisPathology = {
      category: 'Tỷ số bình thường / Sinh lý (Normal Ratio)',
      clinicalMeaning: 'Tỷ số AST/ALT dao động từ 0.7 đến 1.0 là giá trị sinh lý bình thường ở người khỏe mạnh.',
      cellularMechanism: 'Cân bằng giữa tỷ lệ phóng thích sinh lý từ bào tương và tốc độ thanh thải qua xoang gan.',
      kineticsNote: 'Nồng độ ALT huyết thanh phản ánh chủ yếu chuyển hóa alanine-glucose bình thường.'
    };
  }

  // Synthetic function & Alerts
  const syntheticImpairment = Boolean(
    (labs.albumin !== undefined && labs.albumin < 3.5) || 
    (labs.inr !== undefined && labs.inr >= 1.5)
  );
  
  const isAcuteLiverFailureWarning = Boolean(
    (labs.alt > 200 || labs.ast > 200) &&
    (labs.inr !== undefined && labs.inr >= 1.5) &&
    labs.hasEncephalopathy
  );

  const isMassiveTransaminitisWarning = maxTransaminase > 10000;

  // Determine Overall Clinical Risk Tier
  let riskTier: CDSSRiskTier = 'Nguy cơ thấp / Lành tính';
  if (
    isAcuteLiverFailureWarning || 
    isMassiveTransaminitisWarning || 
    hysLawWarning || 
    wilsonIndex.isTriggered || 
    maddreySevere === true
  ) {
    riskTier = 'Tối khẩn cấp / Cấp cứu';
  } else if (
    maxMultiple >= 5 || 
    (labs.totalBilirubin > 5.0 && isConjugatedPredominant) || 
    syntheticImpairment ||
    rhabdoWarning
  ) {
    riskTier = 'Nguy cơ cao';
  } else if (
    maxMultiple > 1 || 
    isAlpElevated || 
    isBilirubinElevated
  ) {
    riskTier = 'Theo dõi tích cực';
  }

  // FIB-4 calculation with age-stratification (BSG 2018 & BMJ 2025)
  let fib4Score: number | undefined;
  let fib4Stage: string | undefined;
  let fib4AgeAdjustedNote: string | undefined;
  if (labs.age && labs.platelets && labs.platelets > 0 && labs.alt > 0) {
    fib4Score = Number(((labs.age * labs.ast) / (labs.platelets * Math.sqrt(labs.alt))).toFixed(2));
    const isElderly = labs.age >= 65;
    const lowCutoff = isElderly ? 2.00 : 1.30;
    const highCutoff = 2.67;

    if (fib4Score < lowCutoff) {
      fib4Stage = `F0 - F1 (Nguy cơ xơ hóa thấp, NPV ~90-95%)`;
    } else if (fib4Score >= lowCutoff && fib4Score <= highCutoff) {
      fib4Stage = `Vùng xám không xác định (Cần đo độ đàn hồi gan VCTE/FibroScan)`;
    } else {
      fib4Stage = `F3 - F4 (Nguy cơ xơ hóa tiến triển / Xơ gan cao, PPV >65-80%)`;
    }

    fib4AgeAdjustedNote = isElderly
      ? `Điểm cắt FIB-4 hiệu chỉnh cho người ≥65 tuổi (BSG 2018 & BMJ 2025): Ngưỡng nguy cơ thấp là < 2.0 (thay vì < 1.30) để tránh chuyển tuyến quá mức do ảnh hưởng sinh lý của tuổi tác.`
      : `Điểm cắt FIB-4 tiêu chuẩn người trưởng thành <65 tuổi: < 1.30 loại trừ xơ hóa tiến triển; > 2.67 chỉ điểm xơ hóa F3-F4.`;
  }

  // NAFLD Fibrosis Score (NFS) calculation (BSG 2018 Table 3 & BMJ 2025)
  // NFS = -1.675 + 0.037*Age + 0.094*BMI + 1.13*IFG/Diabetes(yes=1,no=0) + 0.99*AST/ALT - 0.013*Platelets(10^9/L) - 0.66*Albumin(g/dL)
  let nfsScore: number | undefined;
  let nfsStage: string | undefined;
  let nfsAgeAdjustedNote: string | undefined;
  if (
    labs.age &&
    labs.bmi &&
    labs.platelets &&
    labs.platelets > 0 &&
    labs.alt > 0 &&
    labs.albumin &&
    labs.albumin > 0
  ) {
    const ifgVal = labs.hasDiabetesOrIFG ? 1 : 0;
    const astAltRatio = labs.ast / labs.alt;
    const rawNfs =
      -1.675 +
      0.037 * labs.age +
      0.094 * labs.bmi +
      1.13 * ifgVal +
      0.99 * astAltRatio -
      0.013 * labs.platelets -
      0.66 * labs.albumin;
    nfsScore = Number(rawNfs.toFixed(3));

    const isElderly = labs.age >= 65;
    const lowNfsCutoff = isElderly ? 0.12 : -1.455;
    const highNfsCutoff = 0.675;

    if (nfsScore < lowNfsCutoff) {
      nfsStage = `F0 - F2 (Nguy cơ xơ hóa thấp / Không có xơ hóa tiến triển, NPV ~90%)`;
    } else if (nfsScore >= lowNfsCutoff && nfsScore <= highNfsCutoff) {
      nfsStage = `Điểm số trung gian / Vùng xám (Khuyến cáo đo độ đàn hồi mô gan FibroScan)`;
    } else {
      nfsStage = `F3 - F4 (Nguy cơ xơ hóa nặng / Xơ gan cao, PPV ~90%)`;
    }

    nfsAgeAdjustedNote = isElderly
      ? `Điểm cắt NFS hiệu chỉnh cho người ≥65 tuổi (BSG 2018): Ngưỡng loại trừ nâng lên < 0.12 (thay vì < -1.455) nhằm tăng độ đặc hiệu.`
      : `Điểm cắt NFS tiêu chuẩn: < -1.455 (Nguy cơ thấp), -1.455 đến 0.675 (Trung gian), > 0.675 (Nguy cơ cao).`;
  }

  // APRI calculation
  let apriScore: number | undefined;
  let apriStage: string | undefined;
  if (labs.platelets && labs.platelets > 0 && astUln > 0) {
    apriScore = Number((((labs.ast / astUln) * 100) / labs.platelets).toFixed(2));
    if (apriScore < 0.5) {
      apriStage = 'F0 - F1 (Ít khả năng xơ hóa đáng kể)';
    } else if (apriScore >= 0.5 && apriScore <= 1.5) {
      apriStage = 'F2 - F3 (Nghi ngờ xơ hóa có ý nghĩa lâm sàng)';
    } else {
      apriStage = 'F4 (Khả năng xơ gan cao, chuyên biệt >90%)';
    }
  }

  // MELD calculation (if bilirubin, inr, creatinine provided)
  let meldScore: number | undefined;
  if (labs.totalBilirubin > 0 && labs.inr && labs.inr > 0 && labs.creatinine && labs.creatinine > 0) {
    const bil = Math.max(1.0, labs.totalBilirubin);
    const inr = Math.max(1.0, labs.inr);
    const cr = Math.min(4.0, Math.max(1.0, labs.creatinine));
    const rawMeld = 3.78 * Math.log(bil) + 11.2 * Math.log(inr) + 9.57 * Math.log(cr) + 6.43;
    meldScore = Math.round(Math.min(40, Math.max(6, rawMeld)));
  }

  // Steatotic Liver Disease (SLD) Subclassification (Delphi Consensus & BSG 2018 & BMJ 2025)
  // Evaluates cardiometabolic risk vs alcohol consumption
  const totalAlcoholGrams =
    labs.alcoholIntake ?? (labs.weeklyAlcoholUnits ? labs.weeklyAlcoholUnits * 8 : 0);
  const hasCardiometabolic =
    (labs.bmi !== undefined && labs.bmi >= 23) || Boolean(labs.hasDiabetesOrIFG);

  let sldClassification: CDSSAnalysis['sldClassification'];
  const femaleThresholdGrams = 140; // ~17.5 UK units/week or 20g/day
  const maleThresholdGrams = 210; // ~26.25 UK units/week or 30g/day
  const femaleUpperGrams = 350; // ~43.75 units/week or 50g/day
  const maleUpperGrams = 420; // ~52.5 units/week or 60g/day

  const currentThreshold = labs.gender === 'female' ? femaleThresholdGrams : maleThresholdGrams;
  const currentUpper = labs.gender === 'female' ? femaleUpperGrams : maleUpperGrams;

  if (totalAlcoholGrams > currentUpper || (labs.auditCScore && labs.auditCScore >= 8)) {
    sldClassification = {
      category: 'ALD',
      title: 'Bệnh Gan Liên Quan Rượu (Alcohol-related Liver Disease - ALD)',
      subtext: `Mức tiêu thụ cồn vượt ngưỡng ALD (> ${currentUpper} g/tuần, tương đương > ${currentUpper / 8} đơn vị cồn UK/tuần). Nguy cơ xơ hóa tiến triển nhanh chóng nếu tiếp tục uống.`,
      alcoholIntakeGramsPerWeek: totalAlcoholGrams,
      alcoholThresholdNote: `Ngưỡng ALD: Nữ > 350 g/tuần (>50g/ngày), Nam > 420 g/tuần (>60g/ngày).`,
      metabolicCriteriaMet: hasCardiometabolic,
      recommendations: [
        'Cai rượu hoàn toàn: Biện pháp can thiệp then chốt duy nhất làm ngừng tiến triển tổn thương mô học.',
        'Sàng lọc thang điểm AUDIT: Chuyên gia cai nghiện nếu điểm AUDIT > 19 (lệ thuộc cồn thể nặng).',
        'Đo độ đàn hồi gan (FibroScan) hoặc siêu âm đánh giá xơ gan và tăng áp lực tĩnh mạch cửa.'
      ]
    };
  } else if (hasCardiometabolic && totalAlcoholGrams >= currentThreshold) {
    sldClassification = {
      category: 'MetALD',
      title: 'Bệnh Gan Nhiễm Mỡ Liên Quan Chuyển Hóa & Rượu (MetALD)',
      subtext: `Thỏa tiêu chuẩn tim mạch - chuyển hóa (BMI/tiểu đường) kết hợp mức uống rượu trung gian (${totalAlcoholGrams} g/tuần). Hai yếu tố độc lập này hiệp đồng gia tăng nguy cơ xơ hóa gan.`,
      alcoholIntakeGramsPerWeek: totalAlcoholGrams,
      alcoholThresholdNote: `Khoảng tiêu thụ MetALD: Nữ 140 - 350 g/tuần (20 - 50 g/ngày); Nam 210 - 420 g/tuần (30 - 60 g/ngày).`,
      metabolicCriteriaMet: true,
      recommendations: [
        'Giảm tiêu thụ rượu về dưới ngưỡng an toàn (khuyến khích kiêng hoàn toàn để giảm gánh nặng kép lên ty thể gan).',
        'Kiểm soát tích cực các yếu tố chuyển hóa: Giảm 7-10% trọng lượng cơ thể, ổn định HbA1c và lipid máu.',
        'Đánh giá giai đoạn xơ hóa bằng FIB-4 / NFS, chuyển chuyên khoa nếu FIB-4 > 1.3 (hoặc > 2.0 nếu ≥ 65 tuổi).'
      ]
    };
  } else if (hasCardiometabolic && totalAlcoholGrams < currentThreshold) {
    sldClassification = {
      category: 'MASLD',
      title: 'Bệnh Gan Nhiễm Mỡ Liên Quan Rối Loạn Chuyển Hóa (MASLD / MASH)',
      subtext: `Có ít nhất 1 tiêu chí tim mạch - chuyển hóa (BMI ≥ 23-25, rối loạn đường huyết/T2D) kèm mức uống rượu tối thiểu (< ${currentThreshold} g/tuần).`,
      alcoholIntakeGramsPerWeek: totalAlcoholGrams,
      alcoholThresholdNote: `Tiêu thụ cồn trong giới hạn cho phép của MASLD: Nữ < 140 g/tuần, Nam < 210 g/tuần.`,
      metabolicCriteriaMet: true,
      recommendations: [
        'Điều chỉnh lối sống: Chế độ ăn Địa Trung Hải, tập thể dục nhịp điệu ≥ 150 phút/tuần, mục tiêu giảm cân 5-10%.',
        'Tối ưu hóa điều trị đái tháo đường (ưu tiên chất đồng vận GLP-1 RA hoặc ức chế SGLT2 có bằng chứng cải thiện thoái hóa mỡ gan).',
        'Sử dụng FIB-4 hoặc NFS phân tầng định kỳ mỗi 1-2 năm.'
      ]
    };
  }

  // Statin Safety Evaluation (BSG 2018 & BMJ 2025 guidelines)
  let statinGuidance: CDSSAnalysis['statinGuidance'];
  if (labs.isTakingStatin) {
    const isTransaminaseUnder3x = altMultiples < 3.0 && astMultiples < 3.0;
    if (isTransaminaseUnder3x) {
      statinGuidance = {
        isSafe: true,
        badge: 'An toàn tiếp tục',
        title: 'An Toàn Tiếp Tục Statin (BSG 2018 & BMJ 2025 Guidance)',
        recommendation:
          'Men gan tăng dưới 3 lần ULN không phải là chỉ định ngưng Statin. Bệnh nhân MASLD có nguy cơ tim mạch rất cao; tiếp tục Statin bảo vệ tim mạch và có thể cải thiện viêm gan thoái hóa mỡ.',
        evidenceNote:
          'Theo hướng dẫn Hội Tiêu hóa Anh (BSG 2018) và BMJ 2025: Statin có tính an toàn cao ở người có bất thường men gan mạn tính. Chỉ xem xét tạm ngưng hoặc giảm liều khi ALT/AST tăng liên tục ≥ 3x ULN hoặc có triệu chứng đau cơ/suy gan.'
      };
    } else {
      statinGuidance = {
        isSafe: false,
        badge: 'Tạm ngưng & Đánh giá lại',
        title: 'Men Gan Tăng Đáng Kể (≥ 3x ULN) Trên Bệnh Nhân Dùng Statin',
        recommendation:
          'Khuyến cáo tạm ngừng Statin, kiểm tra lại ALT/AST sau 2-4 tuần; đánh giá nguy cơ tổn thương gan do thuốc (tính điểm RUCAM) và loại trừ các bệnh gan khác.',
        evidenceNote:
          'Nếu ALT/AST trở về bình thường sau khi ngừng statin, có thể cân nhắc đổi sang statin khác với liều thấp hơn hoặc dùng cách ngày kết hợp Ezetimibe.'
      };
    }
  }

  // Isolated ALP & Vitamin D guidance (BMJ 2025 Practice Pointer)
  let isolatedAlpVitaminDAdvice: CDSSAnalysis['isolatedAlpVitaminDAdvice'];
  if (isolatedAlpOrigin === 'suspect_bone_or_other' || (alpMultiples > 1.0 && (labs.ggt || 0) <= ggtUln && altMultiples <= 1.0)) {
    isolatedAlpVitaminDAdvice = {
      isTriggered: true,
      recommendation:
        'Theo hướng dẫn BMJ 2025 & BSG 2018: Thiếu hụt Vitamin D gây cường cận giáp thứ phát là nguyên nhân phổ biến nhất gây tăng ALP xương đơn độc lành tính (gặp tới ~30% ca ALP tăng đơn độc). Khuyến cáo định lượng 25-OH Vitamin D và bổ sung điều chỉnh trước khi chỉ định các kỹ thuật hình ảnh xương tốn kém.'
    };
  }

  // iLFT (Intelligent Liver Testing) Pathway Generation (Newsome et al. Gut 2018 & Dillon et al. 2019)
  const ilftReflexScreen: CDSSAnalysis['ilftReflexScreen'] = {
    tier1StandardScreen: [
      {
        name: 'HBsAg & Anti-HCV',
        code: 'VIRAL-SCREEN',
        targetAetiology: 'Viêm gan virus B và C',
        indication: 'Tất cả trường hợp men gan bất thường không rõ nguyên nhân',
        priority: 'Bắt buộc (Tier 1)'
      },
      {
        name: 'Bilan Tự Miễn (ANA, ASMA, AMA)',
        code: 'AUTOIMMUNE-SCREEN',
        targetAetiology: 'Viêm gan tự miễn (AIH) và Viêm đường mật tiên phát (PBC)',
        indication: 'Tổn thương tế bào gan hoặc ứ mật mạn tính',
        priority: 'Bắt buộc (Tier 1)'
      },
      {
        name: 'Định Lượng Immunoglobulin (IgG, IgM, IgA)',
        code: 'IG-QUANT',
        targetAetiology: 'IgG tăng trong AIH; IgM tăng trong PBC; IgA tăng trong bệnh gan do rượu',
        indication: 'Phân loại bệnh gan mạn tính',
        priority: 'Bắt buộc (Tier 1)'
      },
      {
        name: 'Bilan Sắt: Ferritin & Độ Bão Hòa Transferrin (TSAT)',
        code: 'IRON-STUDIES',
        targetAetiology: 'Bệnh ứ sắt mô di truyền (Hereditary Hemochromatosis)',
        indication: 'TSAT ≥ 45% gợi ý quá tải sắt cần xét nghiệm gen HFE',
        priority: 'Bắt buộc (Tier 1)'
      },
      {
        name: 'Siêu Âm Ổ Bụng (Liver Ultrasound)',
        code: 'US-ABDOMEN',
        targetAetiology: 'Độ nhiễm mỡ gan, bờ gan thô, kích thước lách, dãn đường mật, tĩnh mạch cửa',
        indication: 'Khảo sát hình thái cấu trúc gan mật bắt buộc',
        priority: 'Bắt buộc (Tier 1)'
      }
    ],
    tier2ExtendedScreen: [
      {
        name: 'Ceruloplasmin & Khám Mắt Đèn Khe',
        code: 'WILSON-SCREEN',
        targetAetiology: 'Bệnh Wilson (Rối loạn chuyển hóa đồng)',
        indication: 'Bệnh nhân < 55 tuổi có men gan tăng chưa rõ nguyên nhân',
        priority: 'Mở rộng (Tier 2)'
      },
      {
        name: 'Alpha-1 Antitrypsin (Định lượng & Kiểu hình)',
        code: 'AAT-DEFICIENCY',
        targetAetiology: 'Thiếu hụt Alpha-1 Antitrypsin',
        indication: 'Men gan tăng mạn tính kèm bệnh phổi tắc nghẽn ở người trẻ',
        priority: 'Mở rộng (Tier 2)'
      },
      {
        name: 'Kháng Thể Kháng Transglutaminase Mô (anti-tTG IgA)',
        code: 'CELIAC-SCREEN',
        targetAetiology: 'Bệnh Celiac (Viêm gan phản ứng liên quan gluten)',
        indication: 'Men gan tăng dai dẳng không rõ căn nguyên',
        priority: 'Mở rộng (Tier 2)'
      },
      {
        name: 'Chức Năng Tuyến Giáp (TSH, FT4)',
        code: 'THYROID-FUNCTION',
        targetAetiology: 'Suy giáp hoặc Cường giáp gây rối loạn enzym gan',
        indication: 'Sàng lọc chuyển hóa mở rộng',
        priority: 'Mở rộng (Tier 2)'
      }
    ],
    summary:
      'Quy trình phản xạ tự động iLFT (Intelligent Liver Testing) theo chuẩn BSG 2018 giúp tăng tỷ lệ chẩn đoán đúng lên 43% và rút ngắn thời gian phát hiện xơ gan giai đoạn sớm.'
  };

  // Generate Key Findings
  const keyFindings: string[] = [];
  keyFindings.push(`Phân loại tổn thương: ${pattern} (Chỉ số R = ${rRatio})`);
  keyFindings.push(`Mức độ tăng men gan: ${severity} (ALT: ${altMultiples}x ULN [${labs.alt}/${altUln}], AST: ${astMultiples}x ULN [${labs.ast}/${astUln}])`);
  keyFindings.push(`Tỷ số De Ritis (AST/ALT): ${deRitisRatio} — ${deRitisPathology.category}`);

  if (labs.totalBilirubin > 1.2) {
    keyFindings.push(`Tăng Bilirubin máu: Toàn phần ${labs.totalBilirubin} mg/dL, Trực tiếp ${labs.directBilirubin} mg/dL (${conjugatedPercent}% liên hợp - ${isConjugatedPredominant ? 'Ưu thế liên hợp' : isUnconjugatedPredominant ? 'Ưu thế gián tiếp/tự do' : 'Thể hỗn hợp'})`);
  } else {
    keyFindings.push(`Bilirubin toàn phần trong giới hạn bình thường (${labs.totalBilirubin} mg/dL)`);
  }

  if (syntheticImpairment) {
    keyFindings.push(`Suy giảm chức năng tổng hợp gan: ${labs.albumin && labs.albumin < 3.5 ? `Albumin máu giảm (${labs.albumin} g/dL, t½ ~21 ngày phản ánh mạn tính)` : ''} ${labs.inr && labs.inr >= 1.5 ? `INR kéo dài (${labs.inr}, phản ánh thiếu hụt yếu tố đông máu cấp/nặng, đặc biệt yếu tố VII t½ ~6h)` : ''}`);
  }

  if (isAcuteLiverFailureWarning) {
    keyFindings.push(`CẢNH BÁO TỐI KHẨN SUY GAN CẤP (ALF): Tổn thương tế bào gan cấp tính + Rối loạn đông máu (INR ≥ 1.5) + Bệnh não gan!`);
  }

  if (isMassiveTransaminitisWarning) {
    keyFindings.push(`TĂNG TRANSAMINASE MỨC ĐỘ KHỔNG LỒ (>10,000 U/L): Gợi ý ngộ độc Paracetamol, viêm gan thiếu máu cục bộ (Shock Liver), hoặc nấm độc Amanita phalloides.`);
  }

  if (hysLawWarning) {
    keyFindings.push(`CẢNH BÁO ĐỊNH LUẬT HY (HY'S LAW): ALT ≥ 3x ULN kết hợp Bilirubin toàn phần ≥ 2.0 mg/dL do tổn thương tế bào gan (R > 3) báo hiệu nguy cơ suy gan cấp và tử vong ~10% do thuốc (DILI)!`);
  }

  if (wilsonIndex.isTriggered) {
    keyFindings.push(`CHỈ ĐIỂM BỆNH WILSON CẤP TÍNH (ACG 2017): AST/ALT (${deRitisRatio}) > 2.2 và ALP/Bilirubin (${alpToBilirubinRatio}) < 4.0. Độ đặc hiệu cao cho suy gan cấp do bệnh Wilson!`);
  }

  if (maddreySevere) {
    keyFindings.push(`VIÊM GAN DO RƯỢU MỨC ĐỘ NẶNG: Chỉ số Maddrey DF = ${maddreyScore} (≥ 32) báo hiệu nguy cơ tử vong 30 ngày lên đến 35-50%, có chỉ định xem xét Corticosteroid.`);
  }

  if (rhabdoWarning) {
    keyFindings.push(`CẢNH BÁO TIÊU CƠ VÂN / NGUỒN GỐC CƠ BẮP: AST (${labs.ast} U/L) >> ALT (${labs.alt} U/L)${labs.ck ? ` kèm CK tăng vọt (${labs.ck} U/L)` : ''}. Nguyên nhân chính là tổn thương cơ bắp, không phải tổn thương gan nguyên phát!`);
  }

  if (isolatedAlpOrigin === 'suspect_bone_or_other') {
    keyFindings.push(`ALP TĂNG ĐƠN ĐỘC VỚI GGT BÌNH THƯỜNG: Nguồn gốc tăng ALP nhiều khả năng từ xương (bệnh Paget, gãy xương, di căn, cường cận giáp) hoặc nhau thai, không phải từ gan mật.`);
  }

  // Differential Diagnoses Engine
  const differentials: CDSSAnalysis['differentialDiagnoses'] = [];

  if (isMassiveTransaminitisWarning || maxMultiple > 15) {
    differentials.push({
      disease: 'Tổn thương gan do Acetaminophen (Ngộ độc Paracetamol)',
      likelihood: 'Rất cao',
      clues: 'ALT/AST tăng vọt cực nhanh (>15x đến >10,000 U/L), giảm nhanh sau ngừng độc chất, toan chuyển hóa, tăng lactate máu.',
      recommendedNextStep: 'Định lượng nồng độ Paracetamol huyết thanh khẩn, khí máu động mạch, chỉ định ngay N-Acetylcysteine (NAC) theo đồ thị Rumack-Matthew.'
    });
    differentials.push({
      disease: 'Viêm gan thiếu máu cục bộ (Ischemic Hepatitis / Shock Liver)',
      likelihood: 'Rất cao',
      clues: 'AST thường tăng vọt trước và cao hơn ALT trong 24h đầu, LDH tăng cực cao, tiền sử tụt huyết áp, sốc tim, ngưng tim hoặc suy hô hấp nặng.',
      recommendedNextStep: 'Hồi phục huyết động học và tưới máu gan, siêu âm Doppler mạch máu gan (loại trừ huyết khối tĩnh mạch gan Budd-Chiari), theo dõi chức năng thận.'
    });
    differentials.push({
      disease: 'Viêm gan virus cấp (Acute Viral Hepatitis A, B, C, D, E)',
      likelihood: 'Cao',
      clues: 'ALT > AST (De Ritis < 1.0 trong giai đoạn cấp), vàng da xuất hiện trễ hơn men gan, sốt, mệt mỏi, chán ăn, gan to đau nhẹ.',
      recommendedNextStep: 'Làm IgM anti-HAV, HBsAg, IgM anti-HBc, anti-HCV + HCV RNA, IgM anti-HEV (nếu có yếu tố dịch tễ hoặc mang thai).'
    });
  } else if (rhabdoWarning || extrahepaticAstWarning) {
    differentials.push({
      disease: 'Tổn thương cơ vân / Tiêu cơ vân (Rhabdomyolysis / Strenuous Exercise)',
      likelihood: 'Rất cao',
      clues: `AST tăng vượt trội (${labs.ast} U/L) so với ALT (${labs.alt} U/L), tỷ số AST/ALT = ${deRitisRatio}, ${labs.ck ? `CK = ${labs.ck} U/L (bình thường < 200)` : 'bệnh cảnh tập luyện cường độ cao hoặc chấn thương/nằm bất động'}. Men ALP và GGT thường hoàn toàn bình thường.`,
      recommendedNextStep: 'Định lượng Creatine Kinase (CK) toàn phần, Myoglobin niệu, tổng phân tích nước tiểu, theo dõi chức năng thận và điện giải đồ (nguy cơ tăng kali máu).'
    });
    differentials.push({
      disease: 'Hội chứng Macro-AST (Macro-Aspartate Aminotransferase)',
      likelihood: 'Cần loại trừ',
      clues: 'AST tăng mạn tính đơn độc không triệu chứng, ALT và CK hoàn toàn bình thường, do phức hợp AST gắn với Immunoglobulin (IgG) làm giảm độ thanh thải.',
      recommendedNextStep: 'Nghiệm pháp kết tủa Polyethylene glycol (PEG precipitation) để xác định phức hợp Macro-AST, trấn an bệnh nhân không phải bệnh gan.'
    });
  } else if (wilsonIndex.isTriggered) {
    differentials.push({
      disease: 'Bệnh Wilson thể suy gan bùng phát (Fulminant Wilsonian Liver Disease)',
      likelihood: 'Rất cao',
      clues: `AST:ALT (${deRitisRatio}) > 2.2 kết hợp ALP:Bilirubin (${alpToBilirubinRatio}) < 4.0, thường đi kèm thiếu máu tán huyết Coombs âm tính ở người trẻ.`,
      recommendedNextStep: 'Định lượng Ceruloplasmin huyết thanh, đồng niệu 24h, khám mắt đèn khe tìm vòng Kayser-Fleischer, hội chẩn khẩn cấp ghép gan.'
    });
  } else if (pattern === 'Hepatocellular') {
    if (deRitisRatio >= 2.0 && maxTransaminase <= 500) {
      differentials.push({
        disease: 'Bệnh gan do rượu (Alcoholic Liver Disease / Alcoholic Hepatitis)',
        likelihood: 'Rất cao',
        clues: `AST:ALT > 2:1 (do cồn gây độc màng ty thể giải phóng mAST + thiếu hụt Vitamin B6 ức chế tổng hợp ALT), AST hiếm khi vượt quá 400 U/L. GGT thường tăng cao kèm.`,
        recommendedNextStep: 'Khai thác lượng rượu tiêu thụ (>210g/tuần ở nam, >140g/tuần ở nữ), tính chỉ số Maddrey DF nếu vàng da nặng, bổ sung Thiamine B1 và dinh dưỡng.'
      });
    }

    if (hysLawWarning) {
      differentials.push({
        disease: 'Tổn thương gan do thuốc nặng (Severe DILI - Thỏa tiêu chuẩn Hy\'s Law)',
        likelihood: 'Rất cao',
        clues: 'ALT ≥ 3x ULN kết hợp Bilirubin ≥ 2.0 mg/dL do tổn thương tế bào gan (R > 3), ALP < 2x ULN. Nguy cơ suy gan cấp và tử vong ~10%.',
        recommendedNextStep: 'Rà soát danh mục thuốc kê đơn, OTC, thực phẩm chức năng trong 1-6 tháng qua, ngừng ngay lập tức chất nghi ngờ, tra cứu cơ sở dữ liệu LiverTox.'
      });
    }

    differentials.push({
      disease: 'Viêm gan virus B/C bùng phát cấp hoặc mạn tính (HBV/HCV Flare)',
      likelihood: 'Cao',
      clues: 'ALT ưu thế (De Ritis < 1.0), tăng từ 2x đến 15x ULN, có thể không triệu chứng hoặc mệt mỏi, sụt cân.',
      recommendedNextStep: 'HBsAg, HBeAg, tải lượng HBV DNA định lượng, Anti-HCV, HCV RNA PCR.'
    });

    differentials.push({
      disease: 'Bệnh gan nhiễm mỡ chuyển hóa (MASLD / MASH)',
      likelihood: 'Cao',
      clues: `Men gan tăng mạn tính nhẹ đến vừa (<5x ULN), ALT thường > AST (trừ khi có xơ gan tiến triển tỷ số De Ritis đảo ngược >1.0), liên quan thừa cân (BMI ${labs.bmi || 'chưa ghi nhận'}), đái tháo đường, rối loạn mỡ máu.`,
      recommendedNextStep: 'Siêu âm gan tìm hình ảnh gan nhiễm mỡ, đo độ đàn hồi thoáng qua (FibroScan) xác định độ nhiễm mỡ CAP và độ xơ hóa gan.'
    });

    differentials.push({
      disease: 'Tổn thương gan do thuốc / thảo dược thông thường (DILI / HDS)',
      likelihood: 'Cần loại trừ',
      clues: 'Khởi phát trong vòng vài ngày đến vài tháng sau khi dùng thuốc mới (kháng sinh, NSAIDs, statin, thuốc kháng lao, thực phẩm chức năng giảm cân).',
      recommendedNextStep: 'Ngừng ngay chất nghi ngờ, theo dõi động học men gan sau 2-4 tuần.'
    });

    if (labs.age && labs.age < 55 && !wilsonIndex.isTriggered) {
      differentials.push({
        disease: 'Bệnh Wilson thể mạn tính (Wilson Disease)',
        likelihood: 'Cần loại trừ',
        clues: 'Men gan tăng mạn tính không rõ nguyên nhân ở người trẻ tuổi (<55 tuổi), có thể có rối loạn vận động hoặc tâm thần kinh.',
        recommendedNextStep: 'Định lượng Ceruloplasmin huyết thanh, đồng niệu 24h, khám mắt tìm vòng Kayser-Fleischer.'
      });
    }

    differentials.push({
      disease: 'Bệnh ứ sắt mô di truyền (Hereditary Hemochromatosis)',
      likelihood: 'Cần loại trừ',
      clues: 'Men gan tăng mạn tính nhẹ, có thể kèm sạm da, đái tháo đường, đau khớp, bệnh cơ tim.',
      recommendedNextStep: 'Bộ xét nghiệm sắt: Độ bão hòa Transferrin (nếu ≥45%) và Ferritin huyết thanh; xét nghiệm gen HFE nếu độ bão hòa sắt tăng cao.'
    });

    differentials.push({
      disease: 'Viêm gan tự miễn (Autoimmune Hepatitis - AIH)',
      likelihood: 'Cần loại trừ',
      clues: 'Thường gặp ở phụ nữ trẻ hoặc trung niên, tăng gamma-globulin / IgG huyết thanh, có thể kèm bệnh tự miễn khác (viêm tuyến giáp, viêm khớp).',
      recommendedNextStep: 'Kháng thể tự miễn: ANA, ASMA (Anti-Smooth Muscle), Anti-LKM1, định lượng IgG.'
    });
  } else if (pattern === 'Cholestatic') {
    if (isolatedAlpOrigin === 'suspect_bone_or_other') {
      differentials.push({
        disease: 'Tăng ALP nguồn gốc từ Xương (Bone Disease)',
        likelihood: 'Rất cao',
        clues: 'ALP tăng cao trong khi GGT hoàn toàn bình thường, các men ALT, AST, Bilirubin đều trong giới hạn bình thường.',
        recommendedNextStep: 'Định lượng Canxi, Phospho máu, 25-OH Vitamin D, PTH, chụp X-quang/xạ hình xương (loại trừ bệnh Paget xương, loãng xương, cường cận giáp, gãy xương kín).'
      });
    }

    if (labs.ultrasoundBiliaryDilatation === 'dilated') {
      differentials.push({
        disease: 'Tắc mật ngoài gan do sỏi hoặc khối u (Extrahepatic Biliary Obstruction)',
        likelihood: 'Rất cao',
        clues: 'ALP & GGT tăng cao, Bilirubin trực tiếp tăng ưu thế (>50%), siêu âm có hình ảnh dãn đường mật trong và/hoặc ngoài gan.',
        recommendedNextStep: 'Chụp cộng hưởng từ mật tụy (MRCP) hoặc nội soi mật tụy ngược dòng (ERCP) can thiệp lấy sỏi / đặt stent nếu có nhiễm trùng đường mật (tam chứng Charcot).'
      });
    } else {
      differentials.push({
        disease: 'Tắc mật ngoài gan giai đoạn sớm / Sỏi đường mật chưa dãn',
        likelihood: 'Cao',
        clues: 'ALP tăng ưu thế, vàng mắt vàng da, phân bạc màu, ngứa. Đường mật có thể chưa kịp dãn trong những giờ đầu sau tắc nghẽn cấp.',
        recommendedNextStep: 'Siêu âm kiểm tra lại hoặc chỉ định MRCP/EUS nếu nghi ngờ sỏi ống mật chủ đoạn thấp.'
      });
    }

    differentials.push({
      disease: 'Viêm đường mật tiên phát (Primary Biliary Cholangitis - PBC)',
      likelihood: 'Cao',
      clues: 'Thường gặp ở phụ nữ trung niên (40-60 tuổi), ngứa da, mệt mỏi mạn tính, ALP và GGT tăng kéo dài, đường mật không dãn trên siêu âm.',
      recommendedNextStep: 'Định lượng kháng thể kháng ty thể (AMA - Anti-Mitochondrial Antibody, dương tính >95% ở PBC), IgM huyết thanh.'
    });

    differentials.push({
      disease: 'Viêm xơ đường mật tiên phát (Primary Sclerosing Cholangitis - PSC)',
      likelihood: 'Trung bình',
      clues: 'Nam giới trẻ/trung niên, tiền sử viêm loét đại tràng (IBD), hình ảnh hẹp dãn xen kẽ hình chuỗi hạt trên cây đường mật.',
      recommendedNextStep: 'Chụp MRCP đánh giá hình thái cây mật, định lượng IgG4 (loại trừ bệnh đường mật liên quan IgG4).'
    });

    differentials.push({
      disease: 'Ứ mật do thuốc (Drug-Induced Cholestasis)',
      likelihood: 'Cao',
      clues: 'Hay gặp do Amoxicillin-Clavulanate, steroid đồng hóa, thuốc tránh thai uống, Macrolide, thuốc chống loạn thần.',
      recommendedNextStep: 'Rà soát tiền sử dùng thuốc trong vòng 1-6 tháng gần đây, ngừng thuốc và theo dõi ALP/GGT hạ dần.'
    });

    differentials.push({
      disease: 'Bệnh thâm nhiễm gan (Infiltrative Liver Disease)',
      likelihood: 'Trung bình',
      clues: 'ALP tăng rất cao đơn độc trong khi Bilirubin có thể bình thường: Sarcoidosis, lao gan, ung thư biểu mô gan hoặc di căn gan.',
      recommendedNextStep: 'CT ngực bụng cản quang, MRI gan, dấu ấn khối u (AFP, CA 19-9), cân nhắc sinh thiết gan.'
    });
  } else if (pattern === 'Mixed') {
    differentials.push({
      disease: 'Tổn thương gan do thuốc thể hỗn hợp (Mixed DILI)',
      likelihood: 'Rất cao',
      clues: 'Chỉ số R từ 2 đến 5. Tác nhân thường gặp: Fluoroquinolone, TMP-SMZ, Macrolide, Phenytoin, thảo dược.',
      recommendedNextStep: 'Rà soát kỹ tiền sử dùng thuốc và thực phẩm chức năng, ngừng chất gây nghi ngờ.'
    });
    differentials.push({
      disease: 'Tắc mật cấp tính giai đoạn sớm (Early Acute Choledocholithiasis)',
      likelihood: 'Cao',
      clues: 'Sỏi di chuyển có thể làm transaminase phóng thích đột ngột trước khi ALP tăng vọt, tạo hình ảnh tổn thương hỗn hợp thoáng qua.',
      recommendedNextStep: 'Siêu âm cấp cứu đường mật, theo dõi động học men gan sau 24-48 giờ.'
    });
    differentials.push({
      disease: 'Hội chứng chồng lấp tự miễn (Autoimmune Overlap Syndrome: AIH-PBC / AIH-PSC)',
      likelihood: 'Trung bình',
      clues: 'Đồng thời có đặc điểm hoại tử tế bào gan và tổn thương đường mật mạn tính.',
      recommendedNextStep: 'Đo kháng thể ANA, ASMA, AMA, IgG, IgM và chụp MRCP kết hợp sinh thiết gan chuyên khoa.'
    });
  } else if (pattern === 'Isolated Hyperbilirubinemia') {
    if (isUnconjugatedPredominant) {
      if (labs.totalBilirubin < 4.5) {
        differentials.push({
          disease: 'Hội chứng Gilbert (Gilbert Syndrome)',
          likelihood: 'Rất cao',
          clues: 'Tăng Bilirubin gián tiếp nhẹ (<3-4 mg/dL), các men ALT, AST, ALP, GGT hoàn toàn bình thường, tăng lên khi nhịn đói, mệt mỏi hoặc nhiễm trùng nhẹ.',
          recommendedNextStep: 'Không cần xét nghiệm xâm lấn nếu không có tán huyết. Tư vấn bệnh nhân đây là biến thể lành tính, tiên lượng hoàn toàn bình thường.'
        });
      }
      differentials.push({
        disease: 'Tán huyết ngoại mạch hoặc nội mạch (Hemolysis)',
        likelihood: 'Cao',
        clues: 'Tăng sản xuất Bilirubin tự do vượt quá khả năng liên hợp của gan, có thể kèm thiếu máu, lách to, nước tiểu sẫm màu.',
        recommendedNextStep: 'Tổng phân tích tế bào máu (Hb giảm), Haptoglobin (giảm), Hồng cầu lưới (tăng), LDH (tăng), nghiệm pháp Coombs trực tiếp/gián tiếp.'
      });
    } else if (isConjugatedPredominant) {
      differentials.push({
        disease: 'Hội chứng Dubin-Johnson / Rotor (Direct Hyperbilirubinemia)',
        likelihood: 'Trung bình',
        clues: 'Rối loạn bài tiết bilirubin liên hợp bẩm sinh lành tính hiếm gặp, bilirubin trực tiếp chiếm >50%, men gan và ALP hoàn toàn bình thường.',
        recommendedNextStep: 'Loại trừ các bệnh lý tắc mật cơ học hoặc bệnh gan thâm nhiễm trước khi nghĩ tới bất thường di truyền lành tính.'
      });
    }
  }

  // Primary Impression summary
  let primaryImpression = '';
  if (isAcuteLiverFailureWarning) {
    primaryImpression = 'TỔN THƯƠNG GAN CẤP NẶNG KÈM BỆNH NÃO GAN VÀ RỐI LOẠN ĐÔNG MÁU - NGUY CƠ SUY GAN CẤP (ALF)';
  } else if (isMassiveTransaminitisWarning) {
    primaryImpression = 'TĂNG MEN GAN MỨC ĐỘ KHỔNG LỒ (>10,000 U/L) - NGUY CƠ HOẠI TỬ TẾ BÀO GAN CẤP TÍNH';
  } else if (rhabdoWarning) {
    primaryImpression = 'TỔN THƯƠNG CƠ VÂN / TIÊU CƠ VÂN (AST >> ALT, CK TĂNG VỌT) - NGUỒN GỐC NGOÀI GAN';
  } else if (wilsonIndex.isTriggered) {
    primaryImpression = 'CẢNH BÁO BÙNG PHÁT BỆNH WILSON CẤP TÍNH (AST/ALT > 2.2 & ALP/BILIRUBIN < 4.0)';
  } else if (maddreySevere) {
    primaryImpression = `VIÊM GAN DO RƯỢU MỨC ĐỘ NẶNG (MADDREY DF = ${maddreyScore} ≥ 32) - CHỈ ĐỊNH CORTICOSTEROID`;
  } else if (hysLawWarning) {
    primaryImpression = 'TỔN THƯƠNG GAN DO THUỐC (DILI) THỎA TIÊU CHUẨN ĐỊNH LUẬT HY (HY\'S LAW)';
  } else if (pattern === 'Hepatocellular') {
    if (deRitisRatio >= 2.0 && maxTransaminase <= 500) {
      primaryImpression = 'TỔN THƯƠNG HOẠI TỬ TẾ BÀO GAN ƯU THẾ AST (DE RITIS > 2) - GỢI Ý BỆNH GAN DO RƯỢU / XƠ GAN';
    } else {
      primaryImpression = `TỔN THƯƠNG HOẠI TỬ TẾ BÀO GAN (HEPATOCELLULAR INJURY, R = ${rRatio}) - MỨC ĐỘ ${severity.toUpperCase()}`;
    }
  } else if (pattern === 'Cholestatic') {
    if (isolatedAlpOrigin === 'suspect_bone_or_other') {
      primaryImpression = 'TĂNG ALKALINE PHOSPHATASE (ALP) ĐƠN ĐỘC GỢI Ý NGUỒN GỐC NGOÀI GAN (XƯƠNG / NHAU THAI)';
    } else {
      primaryImpression = `HỘI CHỨNG Ứ MẬT (CHOLESTATIC PATTERN, R = ${rRatio}) - ${labs.ultrasoundBiliaryDilatation === 'dilated' ? 'TẮC MẬT NGOÀI GAN' : 'CẦN PHÂN BIỆT Ứ MẬT TRONG GAN VÀ NGOÀI GAN'}`;
    }
  } else if (pattern === 'Mixed') {
    primaryImpression = `TỔN THƯƠNG GAN DẠNG HỖN HỢP (MIXED HEPATOCELLULAR-CHOLESTATIC, R = ${rRatio})`;
  } else if (pattern === 'Isolated Hyperbilirubinemia') {
    primaryImpression = `TĂNG BILIRUBIN ĐƠN ĐỘC (${isUnconjugatedPredominant ? 'ƯU THẾ GIÁN TIẾP - GỢI Ý GILBERT / TÁN HUYẾT' : 'ƯU THẾ LIÊN HỢP'})`;
  } else {
    primaryImpression = 'SINH HÓA GAN TRONG GIỚI HẠN BÌNH THƯỜNG HOẶC BIẾN THIÊN TỐI THIỂU';
  }

  // Step-by-Step Recommendations according to ACG 2017 & De Ritis Guidelines
  const stepByStepRecommendations: string[] = [];

  if (isAcuteLiverFailureWarning) {
    stepByStepRecommendations.push('CẤP CỨU TỐI KHẨN: Chuyển ngay bệnh nhân đến trung tâm có Đơn vị Hồi sức Gan Mật / Ghép gan.');
    stepByStepRecommendations.push('Theo dõi sát tri giác, đường huyết mao mạch, đông máu toàn bộ (PT/INR, Fibrinogen), khí máu động mạch.');
    stepByStepRecommendations.push('Cân nhắc truyền N-Acetylcysteine (NAC) tĩnh mạch sớm ngay cả khi không rõ tiền sử ngộ độc Paracetamol.');
  } else if (rhabdoWarning) {
    stepByStepRecommendations.push('Kiểm tra ngay Creatine Kinase (CK) toàn phần, Myoglobin niệu và điện giải đồ (đặc biệt Kali máu).');
    stepByStepRecommendations.push('Truyền dịch tích cực bảo vệ thận, kiềm hóa nước tiểu nếu có tiêu cơ vân, tạm dừng vận động mạnh.');
    stepByStepRecommendations.push('Tránh nhầm lẫn tăng AST nguồn gốc cơ với viêm gan cấp; không cần can thiệp gan mật chuyên sâu nếu CK hạ dần.');
  } else {
    stepByStepRecommendations.push('Rà soát và ngưng ngay tất cả các thuốc gây độc gan tiềm tàng, thực phẩm chức năng, thảo dược và rượu bia.');
    
    if (maddreySevere) {
      stepByStepRecommendations.push(`Chỉ số Maddrey DF = ${maddreyScore} ≥ 32: Khám loại trừ nhiễm trùng (cấy máu, chọc dịch màng bụng), xuất huyết tiêu hóa, sau đó cân nhắc điều trị Prednisolone 40 mg/ngày trong 28 ngày.`);
    }

    if (pattern === 'Hepatocellular') {
      if (maxMultiple >= 5) {
        stepByStepRecommendations.push('Bilan virus cấp: HBsAg, IgM anti-HBc, anti-HCV (kèm HCV RNA), IgM anti-HAV.');
        stepByStepRecommendations.push('Định lượng Paracetamol huyết thanh và siêu âm Doppler mạch máu gan (loại trừ tắc tĩnh mạch gan Budd-Chiari).');
        stepByStepRecommendations.push('Xét nghiệm miễn dịch: ANA, ASMA, IgG toàn phần; Ceruloplasmin nếu tuổi < 55.');
      } else {
        stepByStepRecommendations.push('Bilan cơ bản Bậc 1: Siêu âm bụng tổng quát (gan nhiễm mỡ, lách to, tĩnh mạch cửa); HBsAg, anti-HCV.');
        stepByStepRecommendations.push('Đánh giá hội chứng chuyển hóa: Glucose đói, HbA1c, Lipid máu, BMI.');
        stepByStepRecommendations.push('Nếu tăng men kéo dài >3-6 tháng không rõ nguyên nhân (Bậc 2): Ferritin, Độ bão hòa Transferrin, ANA, ASMA, Ceruloplasmin, Alpha-1 Antitrypsin, Kháng thể Celiac (anti-tTG IgA), TSH.');
      }
    } else if (pattern === 'Cholestatic') {
      stepByStepRecommendations.push('Khẳng định nguồn gốc gan của ALP: Kiểm tra GGT hoặc 5\'-Nucleotidase (nếu GGT bình thường, tìm nguyên nhân từ xương như Paget, loãng xương, cường cận giáp).');
      stepByStepRecommendations.push('Siêu âm hạ sườn phải khẩn: Phân biệt dãn đường mật (tắc mật ngoài gan) hay không dãn đường mật (ứ mật trong gan).');
      if (labs.ultrasoundBiliaryDilatation === 'dilated') {
        stepByStepRecommendations.push('Nếu đường mật dãn: Chỉ định MRCP hoặc hội chẩn can thiệp ERCP lấy sỏi / đặt stent đường mật.');
      } else {
        stepByStepRecommendations.push('Nếu đường mật không dãn: Xét nghiệm kháng thể kháng ty thể (AMA) để chẩn đoán PBC, định lượng IgG4 để loại trừ viêm xơ đường mật liên quan IgG4.');
        stepByStepRecommendations.push('Nếu AMA âm tính và ALP vẫn tăng kéo dài: Chỉ định MRCP đánh giá nhánh mật nhỏ/vừa hoặc sinh thiết gan.');
      }
    } else if (pattern === 'Isolated Hyperbilirubinemia') {
      if (isUnconjugatedPredominant) {
        stepByStepRecommendations.push('Kiểm tra công thức máu, hồng cầu lưới, LDH, Haptoglobin để loại trừ tán huyết.');
        stepByStepRecommendations.push('Nếu không có tán huyết và các men gan bình thường: Hướng tới Hội chứng Gilbert, giải thích cơ chế lành tính và trấn an bệnh nhân.');
      } else {
        stepByStepRecommendations.push('Siêu âm bụng loại trừ tắc mật cơ học giai đoạn sớm.');
        stepByStepRecommendations.push('Đánh giá các bệnh di truyền bài tiết mật hiếm gặp (Dubin-Johnson, Rotor) hoặc ứ mật sau phẫu thuật.');
      }
    }

    if (fib4Score && fib4Score > 2.67) {
      stepByStepRecommendations.push(`Điểm FIB-4 (${fib4Score}) cảnh báo xơ hóa gan tiến triển: Hội chẩn chuyên khoa Tiêu hóa - Gan mật, chỉ định đo độ đàn hồi gan (FibroScan) và tầm soát giãn tĩnh mạch thực quản.`);
    }
  }

  const guidelineReferences = [
    'ACG Clinical Guideline: Evaluation of Abnormal Liver Chemistries (Am J Gastroenterol 2017; 112:18-35)',
    'British Society of Gastroenterology (BSG) Guidelines on the Management of Abnormal Liver Blood Tests (Gut 2018; 67:6-19)',
    'Interpreting Abnormal Liver Blood Test Results: Clinical Practice Pointer (BMJ 2025; 391:e082648)',
    'Drug-Induced Liver Injury: A 2023 Update (Journal of Toxicology and Environmental Health 2023; 26:1-25)',
    'The De Ritis Ratio: The Past, Present, and Future of a Classic Biochemical Marker (Clin Biochem Rev 2013; 34:117-130)',
    'Multi-Society Delphi Consensus Statement on New Fatty Liver Nomenclature (MASLD / MetALD / ALD)'
  ];

  return {
    pattern,
    rRatio,
    deRitisRatio,
    altMultiples,
    astMultiples,
    alpMultiples,
    severity,
    riskTier,
    conjugatedPercent,
    isConjugatedPredominant,
    isUnconjugatedPredominant,
    syntheticImpairment,
    isAcuteLiverFailureWarning,
    isMassiveTransaminitisWarning,
    hysLawWarning,
    rhabdoWarning,
    extrahepaticAstWarning,
    wilsonIndex,
    maddreyScore,
    maddreySevere,
    isolatedAlpOrigin,
    isolatedAlpVitaminDAdvice,
    deRitisPathology,
    fib4Score,
    fib4Stage,
    fib4AgeAdjustedNote,
    nfsScore,
    nfsStage,
    nfsAgeAdjustedNote,
    sldClassification,
    statinGuidance,
    ilftReflexScreen,
    apriScore,
    apriStage,
    meldScore,
    primaryImpression,
    keyFindings,
    differentialDiagnoses: differentials,
    stepByStepRecommendations,
    guidelineReferences
  };
}
